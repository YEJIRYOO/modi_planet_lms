#!/usr/bin/env python3
import argparse, json, math, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).parent

class Hardware:
    def __init__(self, mode, factory=None): self.requested=mode; self.factory=factory; self.bundle=None; self.error=None; self.next_retry=0; self.retry_delay=1; self.lock=threading.RLock(); self.timer=None
    @property
    def mode(self): return 'real' if self.bundle else 'mock'
    def connect(self):
        with self.lock:
            if self.requested=='mock' or self.bundle or time.monotonic()<self.next_retry: return
            bundle=None
            try:
                if self.factory: bundle=self.factory()
                else:
                    from modi_plus import MODIPlus
                    bundle=MODIPlus()
                deadline=time.monotonic()+5
                while time.monotonic()<deadline and not (bundle.imus and bundle.buttons): time.sleep(.1)
                if not bundle.imus or not bundle.buttons: raise RuntimeError(f'1942 requires IMU and Button modules (found imu={len(bundle.imus)}, button={len(bundle.buttons)})')
                self.bundle=bundle
                self.error=None
                self.retry_delay=1
                print(f'1942 hardware ready: IMU={len(bundle.imus)}, Button={len(bundle.buttons)}, LED={len(bundle.leds)}, Motor={len(bundle.motors)}')
            except Exception as exc:
                if bundle:
                    try: bundle.close()
                    except Exception: pass
                self.error=str(exc)
                self.next_retry=time.monotonic()+self.retry_delay
                self.retry_delay=min(15,self.retry_delay*2)
    def invalidate(self,exc):
        bundle,self.bundle=self.bundle,None; self.error=f'connection lost: {exc}'; self.next_retry=time.monotonic()+self.retry_delay; self.retry_delay=min(15,self.retry_delay*2)
        if bundle:
            try: bundle.close()
            except Exception: pass
    def status(self):
        self.connect(); return {'status':'ok','mode':self.mode,'connected':bool(self.bundle),'error':self.error,'retrying':self.requested!='mock' and not self.bundle,'modules':len(self.bundle.modules) if self.bundle else 0}
    def read(self, mock):
        try: return self._read(mock)
        except Exception as exc:
            if self.bundle: self.invalidate(exc)
            raise
    def _read(self, mock):
        with self.lock:
            self.connect()
            if self.requested=='real' and not self.bundle: raise RuntimeError(self.error or 'MODI+ is not connected')
            if self.bundle:
                pitch=float(self.bundle.imus[0].angle_y); roll=float(self.bundle.imus[0].angle_x); button=bool(self.bundle.buttons[0].pressed)
            else:
                pitch=float(mock.get('pitch',0)); roll=float(mock.get('roll',0)); button=bool(mock.get('button',False))
            if not math.isfinite(pitch) or not math.isfinite(roll): raise RuntimeError('IMU returned invalid data')
            pitch=max(-90,min(90,pitch)); roll=max(-90,min(90,roll))
            if self.bundle:
                if self.bundle.motors:
                    self.bundle.motors[0].set_speed(round(roll*60/90)); self._watchdog()
                if self.bundle.leds: self.bundle.leds[0].set_rgb(*( (255,70,20) if button else (20,90,255) ))
            return {'mode':self.mode,'controls':{'pitch':pitch,'roll':roll},'attack':button}
    def _watchdog(self):
        if self.timer: self.timer.cancel()
        self.timer=threading.Timer(.5,self.stop_motors); self.timer.daemon=True; self.timer.start()
    def stop_motors(self):
        with self.lock:
            if self.bundle:
                for motor in self.bundle.motors: motor.stop()
    def close(self):
        with self.lock:
            if self.timer: self.timer.cancel()
            if not self.bundle: return
            for motor in self.bundle.motors: motor.stop()
            for led in self.bundle.leds: led.turn_off()
            self.bundle.close(); self.bundle=None

class Handler(BaseHTTPRequestHandler):
    hardware=None
    assets={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css'}
    def send_json(self,status,value):
        try:
            data=json.dumps(value).encode(); self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError): pass
    def do_GET(self):
        if self.path=='/api/health': self.send_json(200,self.hardware.status()); return
        if self.path in self.assets:
            path=ROOT/self.assets[self.path]; data=path.read_bytes(); kind='text/html' if path.suffix=='.html' else 'text/javascript' if path.suffix=='.js' else 'text/css'; self.send_response(200); self.send_header('Content-Type',kind); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        self.send_json(404,{'error':'not found'})
    def do_POST(self):
        try:
            if self.path=='/api/stop': self.hardware.stop_motors(); self.send_json(200,{'stopped':True}); return
            if self.path!='/api/state': self.send_json(404,{'error':'not found'}); return
            length=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(length) or b'{}'); self.send_json(200,self.hardware.read(body))
        except Exception as exc: self.send_json(503,{'error':str(exc)})
    def log_message(self,*_): pass

def main():
    p=argparse.ArgumentParser(); p.add_argument('--mode',choices=('auto','real','mock'),default='auto'); p.add_argument('--port',type=int,default=8101); args=p.parse_args(); Handler.hardware=Hardware(args.mode); server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler); print(f'1942 running at http://127.0.0.1:{args.port} ({args.mode})')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: Handler.hardware.close(); server.server_close()
if __name__=='__main__': main()
