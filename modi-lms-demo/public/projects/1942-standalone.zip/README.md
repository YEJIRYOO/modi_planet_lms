# 1942

```sh
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python app.py --mode auto --port 8101
```

Open <http://127.0.0.1:8101>. Real mode uses the first IMU and Button; Motor and LED are optional outputs. IMU calibration runs before each game.
