#!/usr/bin/env python3
import argparse,json,random,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent
class ModuleUnavailableError(RuntimeError):pass

class TimesGame:
 def __init__(self,mode,factory=None):
  self.requested=mode;self.factory=factory;self.bundle=None;self.error=None;self.next_retry=0;self.retry_delay=1;self.lock=threading.RLock();self.rng=random.Random();self.last_button=False;self.last_direction='origin';self.direction_since=0;self.last_repeat=0;self.sound_timer=None;self.sound_generation=0;self.new_game('standard')
 @property
 def mode(self):return'real'if self.bundle else'mock'
 def connect(self):
  with self.lock:
   if self.requested=='mock'or self.bundle or time.monotonic()<self.next_retry:return
   bundle=None
   try:
    if self.factory:bundle=self.factory()
    else:
     from modi_plus import MODIPlus
     bundle=MODIPlus()
    deadline=time.monotonic()+5
    while time.monotonic()<deadline and not(bundle.joysticks and bundle.buttons):time.sleep(.1)
    self.bundle=bundle;self.error=None if bundle.joysticks and bundle.buttons else'Waiting for Joystick and Button modules';self.retry_delay=1
   except Exception as exc:
    self.error=str(exc);self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
    if bundle:
     try:bundle.close()
     except Exception:pass
 def invalidate(self,exc):
  bundle,self.bundle=self.bundle,None;self.error=f'connection lost: {exc}';self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
  if bundle:
   try:bundle.close()
   except Exception:pass
 def new_game(self,difficulty):
  self.difficulty=difficulty if difficulty in('easy','standard','challenge')else'standard';self.question=0;self.correct=0;self.score=0;self.streak=0;self.answer=0;self.offset=0;self.feedback='ready';self.finished=False;self.next_at=0;self.make_question()
 def make_question(self):
  ranges={'easy':(2,5),'standard':(2,9),'challenge':(6,12)};low,high=ranges[self.difficulty];self.left=self.rng.randint(low,high);self.right=self.rng.randint(1,9 if self.difficulty!='challenge'else 12);self.answer=0;self.offset=0;self.feedback='ready';self.question+=1
  if self.bundle:
   if self.bundle.leds:self.bundle.leds[0].set_rgb(35,110,255)
 def tone(self,frequency):
  if not self.bundle or not self.bundle.speakers:return
  self.sound_generation+=1;generation=self.sound_generation;self.bundle.speakers[0].set_tune(frequency,75)
  if self.sound_timer:self.sound_timer.cancel()
  self.sound_timer=threading.Timer(.28,self.silence,args=(generation,));self.sound_timer.daemon=True;self.sound_timer.start()
 def silence(self,generation=None):
  with self.lock:
   if generation is not None and generation!=self.sound_generation:return
   if self.bundle and self.bundle.speakers:
    try:self.bundle.speakers[0].set_tune(0,0)
    except Exception as exc:self.invalidate(exc)
 def state(self,body):
  with self.lock:
   try:return self._state(body)
   except(ModuleUnavailableError,ValueError,TypeError):raise
   except Exception as exc:
    if self.bundle:self.invalidate(exc)
    raise
 def _state(self,body):
  self.connect()
  if self.requested=='real'and not self.bundle:raise RuntimeError(self.error or'MODI+ is not connected')
  if self.bundle and(not self.bundle.joysticks or not self.bundle.buttons):raise ModuleUnavailableError('Connected to Network; waiting for Joystick and Button modules')
  requested_difficulty=str(body.get('difficulty',self.difficulty))
  if body.get('reset'):self.new_game(requested_difficulty)
  now=time.monotonic()
  if self.next_at and now>=self.next_at:
   self.next_at=0
   if self.question>=10:self.finished=True
   else:self.make_question()
  physical=bool(self.bundle.buttons[0].pressed)if self.bundle else False;button=physical or bool(body.get('button',False));submitted=button and not self.last_button;self.last_button=button
  direction=(self.bundle.joysticks[0].direction or'origin')if self.bundle else str(body.get('joystick','origin'));action='origin'
  if direction=='origin':self.direction_since=0
  elif direction!=self.last_direction:action=direction;self.direction_since=now;self.last_repeat=now
  else:
   interval=.10 if direction in('left','right')else.18
   if now-self.direction_since>=.35 and now-self.last_repeat>=interval:action=direction;self.last_repeat=now
  self.last_direction=direction
  has_dial=bool(self.bundle and self.bundle.dials)
  if has_dial:base=round(max(0,min(100,float(self.bundle.dials[0].turn))))
  elif self.bundle:base=self.answer-self.offset
  else:base=round(max(0,min(100,float(body.get('dial',self.answer-self.offset)))))
  delta={'left':-1,'right':1,'up':10,'down':-10}.get(action,0);self.offset+=delta;self.answer=max(0,min(144,base+self.offset))
  if submitted and not self.finished and not self.next_at:
   expected=self.left*self.right
   if self.answer==expected:
    self.correct+=1;self.streak+=1;self.score+=100+min(100,self.streak*10);self.feedback='correct';self.next_at=now+.85
    if self.bundle and self.bundle.leds:self.bundle.leds[0].set_rgb(65,255,100)
    self.tone(1046)
   else:
    self.streak=0;self.score=max(0,self.score-10);self.feedback='wrong'
    if self.bundle and self.bundle.leds:self.bundle.leds[0].set_rgb(255,60,35)
    self.tone(698)
  return{'mode':self.mode,'difficulty':self.difficulty,'question':self.question,'total':10,'left':self.left,'right':self.right,'answer':self.answer,'expected':self.left*self.right if self.finished else None,'score':self.score,'correct':self.correct,'streak':self.streak,'feedback':self.feedback,'finished':self.finished,'submitted':submitted,'has_dial':has_dial,'has_led':bool(self.bundle and self.bundle.leds),'has_speaker':bool(self.bundle and self.bundle.speakers)}
 def close(self):
  if self.sound_timer:self.sound_timer.cancel()
  if self.bundle:
   for led in self.bundle.leds:led.turn_off()
   for speaker in self.bundle.speakers:speaker.set_tune(0,0)
   self.bundle.close();self.bundle=None

class Handler(BaseHTTPRequestHandler):
 game=None
 def send(self,status,value,kind='application/json'):
  try:data=json.dumps(value).encode()if kind=='application/json'else value;self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
  except(BrokenPipeError,ConnectionResetError):pass
 def do_GET(self):
  if self.path=='/':self.send(200,(ROOT/'index.html').read_bytes(),'text/html; charset=utf-8')
  elif self.path=='/styles.css':self.send(200,(ROOT/'styles.css').read_bytes(),'text/css; charset=utf-8')
  elif self.path=='/app.js':self.send(200,(ROOT/'app.js').read_bytes(),'text/javascript; charset=utf-8')
  elif self.path=='/api/health':self.game.connect();self.send(200,{'mode':self.game.mode,'connected':bool(self.game.bundle),'error':self.game.error})
  else:self.send(404,{'error':'not found'})
 def do_POST(self):
  try:
   if self.path!='/api/state':self.send(404,{'error':'not found'});return
   size=int(self.headers.get('Content-Length','0'));self.send(200,self.game.state(json.loads(self.rfile.read(size)or b'{}')))
  except Exception as exc:self.send(503,{'error':str(exc)})
 def log_message(self,*_):pass
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('auto','real','mock'),default='auto');p.add_argument('--port',type=int,default=8502);a=p.parse_args();Handler.game=TimesGame(a.mode);server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print(f'Times Table Quest · http://127.0.0.1:{a.port}')
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:Handler.game.close();server.server_close()
if __name__=='__main__':main()
