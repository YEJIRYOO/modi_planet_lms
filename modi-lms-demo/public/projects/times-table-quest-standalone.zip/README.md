# Times Table Quest

Joystick으로 답을 만들고 Button으로 제출하는 10문제 구구단 게임입니다. 연속 정답 보너스와 MODI+ LED·Speaker 피드백을 제공합니다.

## MODI+ 모듈

- 필수: Network, Joystick, Button
- 선택: Dial, LED, Speaker
- Joystick 좌/우: 답 ±1
- Joystick 위/아래: 답 ±10
- Button: 제출
- Dial: 답을 0–100 범위에서 빠르게 이동
- LED: 대기·정답·오답 색
- Speaker: 정답 1046Hz, 오답 698Hz

Joystick 방향을 길게 누르면 0.35초 후부터 자동 반복됩니다. Dial이 없어도 Joystick만으로 모든 답을 입력할 수 있습니다.

## 실행

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py --mode real --port 8502
```

브라우저: <http://127.0.0.1:8502>

Mock 모드:

```sh
python app.py --mode mock --port 8502
```

## 난이도

- 2–5단: 입문
- 2–9단: 표준 구구단
- 6–12단: 도전

## 자동 복구

필수 모듈이 늦게 연결되면 Network bundle을 유지하며 기다립니다. 실제 USB 통신 오류만 bundle을 폐기하며 1→2→4→8→15초 간격으로 자동 재연결합니다.
