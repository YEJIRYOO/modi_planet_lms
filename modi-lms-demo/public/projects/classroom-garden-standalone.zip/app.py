#!/usr/bin/env python3
import argparse,json,math,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent
class ModuleUnavailableError(RuntimeError):pass

class Garden:
 def __init__(self,mode,factory=None):
  self.requested=mode;self.factory=factory;self.bundle=None;self.error=None;self.next_retry=0;self.retry_delay=1;self.lock=threading.RLock();self.last_button=False;self.last_near=False;self.reset('lesson')
 @property
 def mode(self):return'real'if self.bundle else'mock'
 def connect(self):
  with self.lock:
   if self.requested=='mock'or self.bundle or time.monotonic()<self.next_retry:return
   bundle=None
   try:
    if self.factory:bundle=self.factory()
    else:
     from modi_plus import MODIPlus
     bundle=MODIPlus()
    deadline=time.monotonic()+6
    while time.monotonic()<deadline and not(bundle.envs and bundle.dials and bundle.buttons and bundle.tofs and bundle.leds):time.sleep(.1)
    self.bundle=bundle;ready=bundle.envs and bundle.dials and bundle.buttons and bundle.tofs and bundle.leds;self.error=None if ready else'Waiting for ENV, Dial, Button, ToF and LED modules';self.retry_delay=1
   except Exception as exc:
    self.error=str(exc);self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
    if bundle:
     try:bundle.close()
     except Exception:pass
 def invalidate(self,exc):
  bundle,self.bundle=self.bundle,None;self.error=f'connection lost: {exc}';self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
  if bundle:
   try:bundle.close()
   except Exception:pass
 def reset(self,pace):
  now=time.monotonic();self.pace=pace if pace in('lesson','demo')else'lesson';self.started=now;self.last_update=now;self.growth=0.;self.soil=52.;self.happiness=62.;self.score_float=0.;self.waters=0;self.pets=0;self.event='welcome';self.event_until=now+2;self.last_button=False;self.last_near=False
 @staticmethod
 def band(value,low,high,margin):
  if low<=value<=high:return 1.
  distance=low-value if value<low else value-high
  return max(0.,1-distance/margin)
 def state(self,body):
  with self.lock:
   try:return self._state(body)
   except(ModuleUnavailableError,ValueError,TypeError):raise
   except Exception as exc:
    if self.bundle:self.invalidate(exc)
    raise
 def _state(self,body):
  self.connect()
  if self.requested=='real'and not self.bundle:raise RuntimeError(self.error or'MODI+ is not connected')
  if self.bundle and(not self.bundle.envs or not self.bundle.dials or not self.bundle.buttons or not self.bundle.tofs or not self.bundle.leds):raise ModuleUnavailableError('Network connected; waiting for ENV + Dial + Button + ToF + LED')
  if body.get('reset'):self.reset(str(body.get('pace','lesson')))
  now=time.monotonic();dt=min(1.,max(0.,now-self.last_update));self.last_update=now
  if self.bundle:
   env=self.bundle.envs[0];temperature=float(env.temperature);humidity=float(env.humidity);light=float(env.illuminance);dial=float(self.bundle.dials[0].turn);button=bool(self.bundle.buttons[0].pressed)or bool(body.get('button',False));distance=float(self.bundle.tofs[0].distance)
  else:
   temperature=float(body.get('temperature',23));humidity=float(body.get('humidity',55));light=float(body.get('light',65));dial=float(body.get('dial',45));button=bool(body.get('button',False));distance=float(body.get('distance',100))
  if not all(math.isfinite(v)for v in(temperature,humidity,light,dial,distance)):raise ValueError('sensor returned invalid data')
  temperature=max(-10,min(60,temperature));humidity=max(0,min(100,humidity));light=max(0,min(100,light));dial=max(0,min(100,dial));distance=max(0,min(100,distance))
  temp_q=self.band(temperature,20,26,10);humidity_q=self.band(humidity,40,70,30);light_q=self.band(light,40,82,35);env_quality=(temp_q+humidity_q+light_q)/3
  self.soil=max(0,self.soil-dt*(.025+.02*light_q));pressed=button and not self.last_button;self.last_button=button
  water_amount=round(5+dial*.22,1)
  if pressed:
   before=self.soil;self.soil=min(100,self.soil+water_amount);self.waters+=1;self.event='water';self.event_until=now+1.4
   if before>78:self.happiness=max(0,self.happiness-7);self.score_float=max(0,self.score_float-15)
   else:self.happiness=min(100,self.happiness+3);self.score_float+=8
  near=distance<12
  if near and not self.last_near:
   self.pets+=1;self.happiness=min(100,self.happiness+8);self.score_float+=6;self.event='pet';self.event_until=now+1.5
  self.last_near=distance<18
  soil_q=self.band(self.soil,35,78,28);care_quality=(env_quality*.7+soil_q*.3)
  self.happiness=max(0,min(100,self.happiness+dt*((care_quality-.55)*.075)))
  duration=35*60 if self.pace=='lesson'else 4*60;rate=100/duration
  if env_quality>=.55 and soil_q>=.45 and self.happiness>=35:self.growth=min(100,self.growth+dt*rate*(.55+care_quality*.65));self.score_float+=dt*care_quality*.28
  elif self.soil<18 or self.soil>90:self.happiness=max(0,self.happiness-dt*.08)
  thresholds=(0,18,38,62,84);stage=max(i for i,value in enumerate(thresholds)if self.growth>=value)
  if self.soil<25:status='thirsty'
  elif self.soil>86:status='overwatered'
  elif light<28:status='dark'
  elif temperature<17:status='cold'
  elif temperature>30:status='hot'
  elif humidity<30:status='dry_air'
  elif env_quality>.82 and self.happiness>65:status='happy'
  else:status='growing'
  active_event=self.event if now<self.event_until else None;pose=3 if active_event in('water','pet')else 2 if status in('thirsty','overwatered','dark','cold','hot','dry_air')else 1 if status=='happy'else 0
  if self.bundle:
   rgb=(60,255,105)if status in('happy','growing')else(40,120,255)if status=='thirsty'else(255,190,35)if status in('dark','cold','dry_air')else(255,70,35)
   self.bundle.leds[0].set_rgb(*rgb)
  elapsed=now-self.started
  return{'mode':self.mode,'pace':self.pace,'elapsed':round(elapsed,1),'remaining':round(max(0,duration-elapsed),1),'temperature':round(temperature,1),'humidity':round(humidity,1),'light':round(light,1),'dial':round(dial,1),'distance':round(distance,1),'water_amount':water_amount,'soil':round(self.soil,1),'happiness':round(self.happiness,1),'environment_quality':round(env_quality*100),'growth':round(self.growth,2),'stage':stage,'pose':pose,'status':status,'event':active_event,'score':round(self.score_float),'waters':self.waters,'pets':self.pets,'complete':self.growth>=100}
 def close(self):
  if self.bundle:
   for led in self.bundle.leds:led.turn_off()
   self.bundle.close();self.bundle=None

class Handler(BaseHTTPRequestHandler):
 garden=None
 assets={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css','/assets/classroom-garden.png':'assets/classroom-garden.png'}
 def send(self,status,value,kind='application/json'):
  try:data=json.dumps(value).encode()if kind=='application/json'else value;self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
  except(BrokenPipeError,ConnectionResetError):pass
 def do_GET(self):
  if self.path=='/api/health':self.garden.connect();self.send(200,{'mode':self.garden.mode,'connected':bool(self.garden.bundle),'error':self.garden.error});return
  if self.path.startswith('/assets/plant_stages/')or self.path.startswith('/assets/effect_frames/'):
   path=(ROOT/self.path.lstrip('/')).resolve();assets=(ROOT/'assets').resolve()
   if assets in path.parents and path.suffix=='.png'and path.exists():self.send(200,path.read_bytes(),'image/png');return
  if self.path in self.assets:
   path=ROOT/self.assets[self.path];kind='text/html; charset=utf-8'if path.suffix=='.html'else'text/javascript; charset=utf-8'if path.suffix=='.js'else'text/css; charset=utf-8'if path.suffix=='.css'else'image/png';self.send(200,path.read_bytes(),kind);return
  self.send(404,{'error':'not found'})
 def do_POST(self):
  try:
   if self.path!='/api/state':self.send(404,{'error':'not found'});return
   size=int(self.headers.get('Content-Length','0'));self.send(200,self.garden.state(json.loads(self.rfile.read(size)or b'{}')))
  except Exception as exc:self.send(503,{'error':str(exc)})
 def log_message(self,*_):pass
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('auto','real','mock'),default='auto');p.add_argument('--port',type=int,default=8701);a=p.parse_args();Handler.garden=Garden(a.mode);server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print(f'Classroom Garden · http://127.0.0.1:{a.port}')
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:Handler.garden.close();server.server_close()
if __name__=='__main__':main()
