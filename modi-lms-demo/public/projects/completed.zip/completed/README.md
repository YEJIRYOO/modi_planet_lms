# Independent Projects — Completed

독립 실행 가능한 프로젝트 완성품 7종입니다. MODI+ 프로젝트는 자체 서버와 화면을 포함하며, 손가락 마법 그림판은 MediaPipe CDN 기반 단일 HTML 앱입니다.

| ZIP | 프로젝트 | 주요 MODI+ 모듈 | 기본 포트 |
|---|---|---|---|
| `1942-standalone.zip` | IMU 비행 슈팅 게임 | Network, IMU, Button | 8101 |
| `tilt-match-standalone.zip` | LED 색상 방향 맞추기 | Network, IMU, LED | 8102 |
| `music-studio-standalone.zip` | 8-step 음악 제작기 | Network, Speaker, Button, Dial 또는 Joystick | 8103 |
| `function-shape-standalone.zip` | 함수 개형 맞추기 | Network, Dial, Joystick, Button | 8501 |
| `times-table-quest-standalone.zip` | 구구단 10문제 게임 | Network, Joystick, Button; Dial·LED·Speaker 선택 | 8502 |
| `hand-writing-magic-standalone.zip` | 손가락 마법 그림판 | 웹카메라, MediaPipe CDN | 8601 |
| `classroom-garden-standalone.zip` | 실제 교실 환경으로 키우는 5단계 식물 | Network, ENV, Dial, Button, ToF, LED | 8701 |

## 실행 방법

원하는 ZIP을 별도 폴더에 풀고 실행합니다.

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py --mode real --port <기본 포트>
```

하드웨어 없이 확인하려면 `--mode mock`을 사용합니다. 하나의 MODI+ Network 직렬 포트는 한 프로그램만 사용할 수 있으므로 다른 서버를 먼저 `Ctrl+C`로 종료하세요.

손가락 마법 그림판은 ZIP을 푼 폴더에서 다음과 같이 실행합니다.

```sh
python3 -m http.server 8601
```

브라우저에서 <http://127.0.0.1:8601/hand_wirting.html>을 열고 카메라 권한을 허용합니다.
