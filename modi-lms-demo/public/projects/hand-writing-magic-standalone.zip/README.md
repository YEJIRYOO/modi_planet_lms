# 손가락 마법 그림판

MediaPipe Hand Landmarker로 검지와 엄지의 핀치 동작을 인식해 공중에 그림을 그리는 초등학생용 독립 HTML 앱입니다.

## 기능

- 엄지·검지 붙이기: 그리기
- 손가락 떼기: 커서 이동
- Shift: 보조 그리기 입력
- 무지개 포함 6색, 3가지 굵기
- Undo, Clear, Mirror, PNG 저장
- 별·무지개·고양이·로켓 등 8개 그리기 미션
- 미션 완료 별 스티커와 confetti

## 실행

카메라 권한을 위해 localhost 실행을 권장합니다.

```sh
python3 -m http.server 8601 --directory .
```

브라우저에서 <http://127.0.0.1:8601/hand_wirting.html>을 엽니다.

## CDN

- `@mediapipe/tasks-vision@1.0.1` — jsDelivr
- Hand Landmarker float16 model — Google Cloud Storage

앱 코드와 스타일은 HTML 하나에 포함되며 MediaPipe runtime, WASM과 model만 CDN에서 로드합니다. 카메라 영상은 브라우저 내부에서만 처리됩니다.
