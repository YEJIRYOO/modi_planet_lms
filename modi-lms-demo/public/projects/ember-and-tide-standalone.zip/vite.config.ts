import { defineConfig } from "vite";

export default defineConfig({
  server: {
    port: 5174,
  },
  preview: {
    port: 4173,
  },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
    exclude: ["**/._*", "**/node_modules/**", "**/dist/**"],
  },
});
