# EMBER & TIDE — 학생용 웹 게임

이 압축 파일에는 완성된 웹 게임과 통합 실행기만 들어 있습니다. 실습에서 직접 작성할 `main.py`는 의도적으로 포함하지 않았습니다.

## 1. 압축 해제

ZIP 파일을 풀고 터미널에서 해당 폴더로 이동합니다.

```bash
cd EMBER_AND_TIDE_WEB_GAME
```

## 2. main.py 작성

수업용 Figma Slides 56페이지부터 순서대로 따라 입력해 같은 폴더에 `main.py`를 만듭니다.

## 3. MODI PLUS 연결 및 실행

```bash
./game_run main.py --serial-port /dev/cu.usbmodemXXXX
```

`game_run`은 첫 실행 시 `.venv`와 웹 패키지를 자동으로 설치한 뒤 다음 두 프로그램을 함께 시작합니다.

- 웹 게임: `http://localhost:5174`
- MODI WebSocket: `ws://127.0.0.1:8765`

종료할 때는 실행한 터미널에서 `Ctrl+C`를 누릅니다.

## 필요한 프로그램

- Python 3.11–3.13
- Node.js 20 이상과 npm
- MODI PLUS 네트워크, IMU, JOYSTICK, ENV, BUTTON, LED, SPEAKER 모듈

