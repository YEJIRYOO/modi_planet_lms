import { GameAudio } from "./audio";
import { ModiInput } from "./input";
import { GRAVITY, JUMP_SPEED, MOVE_SPEED } from "./physics";
import { advanceSequence, applyThresholdProgress } from "./puzzles";
import { STAGES, STAGE_SEQUENCES } from "./stages";
import type {
  Direction,
  ElementKind,
  Hazard,
  MapDecoration,
  Platform,
  PlayerState,
  Portal,
  Rect,
  StageConfig,
  StageRuntime,
} from "./types";

interface GameCallbacks {
  onStage: (stage: StageConfig) => void;
  onMission: (index: number, text: string, completed: boolean) => void;
  onProgress: (value: number) => void;
  onActiveElement: (element: ElementKind) => void;
  onLed: (color: [number, number, number], label: string) => void;
  onSpeaker: (label: string) => void;
  onToast: (message: string) => void;
  onVictory: (stats: { restarts: number; elapsed: number; relics: number; totalRelics: number }) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
}

interface EffectRing {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  life: number;
  maxLife: number;
  color: string;
  width: number;
}

const VIEW_WIDTH = 1440;
const VIEW_HEIGHT = 810;
const PLAYER_WIDTH = 54;
const PLAYER_HEIGHT = 78;

const ELEMENT_COLORS: Record<ElementKind, { main: string; glow: string; rgb: [number, number, number] }> = {
  fire: { main: "#ff765c", glow: "#ffb05e", rgb: [100, 22, 8] },
  water: { main: "#59d5ff", glow: "#a3f3ff", rgb: [6, 42, 100] },
};

const directionGlyph: Record<Direction, string> = {
  up: "↑",
  down: "↓",
  left: "←",
  right: "→",
};

function intersects(a: Rect, b: Rect): boolean {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function easeOutCubic(value: number): number {
  return 1 - Math.pow(1 - clamp(value, 0, 1), 3);
}

function createRuntime(): StageRuntime {
  return {
    primaryProgress: 0,
    secondaryProgress: 0,
    puzzleIndex: 0,
    puzzleMistakes: 0,
    gateAOpen: false,
    gateBOpen: false,
    complete: false,
    elapsed: 0,
  };
}

export class ElementGame {
  private readonly context: CanvasRenderingContext2D;
  private readonly audio: GameAudio;
  private readonly backgrounds = new Map<string, HTMLImageElement>();
  private readonly spriteSheet = new Image();
  private stageIndex = 0;
  private stage = STAGES[0];
  private runtime = createRuntime();
  private players: Record<ElementKind, PlayerState>;
  private activeElement: ElementKind = "fire";
  private cameraX = 0;
  private targetCameraX = 0;
  private particles: Particle[] = [];
  private rings: EffectRing[] = [];
  private collectedRelics = new Set<string>();
  private activatedCheckpoints = new Set<string>();
  private lastTime = performance.now();
  private animationFrame = 0;
  private playing = false;
  private paused = false;
  private transitionAt = 0;
  private stageStartedAt = 0;
  private totalStartedAt = 0;
  private restarts = 0;
  private screenShake = 0;
  private lastMissionIndex = -1;
  private lastLed = "";
  private ledPulseClock = 0;
  private trailClock = 0;
  private screenFlash = 0;
  private screenFlashColor = "#ffffff";

  constructor(
    canvas: HTMLCanvasElement,
    private readonly input: ModiInput,
    private readonly callbacks: GameCallbacks,
  ) {
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas 2D context를 만들 수 없습니다.");
    this.context = context;
    this.audio = new GameAudio(input);
    this.players = this.createPlayers(this.stage);
    this.preloadAssets();
    this.animationFrame = requestAnimationFrame(this.loop);
  }

  start(): void {
    this.audio.unlock();
    this.stageIndex = 0;
    this.restarts = 0;
    this.collectedRelics.clear();
    this.totalStartedAt = performance.now();
    this.playing = true;
    this.paused = false;
    this.loadStage(0);
  }

  pause(): void {
    if (!this.playing || this.runtime.complete) return;
    this.paused = true;
  }

  resume(): void {
    this.paused = false;
    this.lastTime = performance.now();
    this.audio.unlock();
  }

  restart(): void {
    this.restarts += 1;
    this.loadStage(this.stageIndex);
    this.paused = false;
  }

  isPaused(): boolean {
    return this.paused;
  }

  isPlaying(): boolean {
    return this.playing;
  }

  destroy(): void {
    cancelAnimationFrame(this.animationFrame);
  }

  private preloadAssets(): void {
    for (const stage of STAGES) {
      const image = new Image();
      image.decoding = "async";
      image.src = stage.background;
      this.backgrounds.set(stage.background, image);
    }
    this.spriteSheet.decoding = "async";
    this.spriteSheet.src = "/assets/heroes-spritesheet.png";
  }

  private createPlayers(stage: StageConfig): Record<ElementKind, PlayerState> {
    const create = (element: ElementKind): PlayerState => ({
      element,
      x: stage.starts[element].x,
      y: stage.starts[element].y,
      width: PLAYER_WIDTH,
      height: PLAYER_HEIGHT,
      velocityX: 0,
      velocityY: 0,
      grounded: false,
      facing: 1,
      reachedExit: false,
      spawnX: stage.starts[element].x,
      spawnY: stage.starts[element].y,
      animationTime: 0,
    });
    return { fire: create("fire"), water: create("water") };
  }

  private loadStage(index: number): void {
    this.stageIndex = index;
    this.stage = STAGES[index];
    this.runtime = createRuntime();
    this.players = this.createPlayers(this.stage);
    this.activeElement = "fire";
    this.cameraX = 0;
    this.targetCameraX = 0;
    this.particles = [];
    this.rings = [];
    this.activatedCheckpoints.clear();
    this.screenFlash = 0;
    this.transitionAt = 0;
    this.stageStartedAt = performance.now();
    this.lastMissionIndex = -1;
    this.setLed(ELEMENT_COLORS.fire.rgb, "EMBER 활성");
    this.callbacks.onStage(this.stage);
    this.callbacks.onActiveElement(this.activeElement);
    this.callbacks.onProgress(0);
    this.updateMission(true);
  }

  private loop = (time: number): void => {
    const delta = Math.min(0.033, Math.max(0, (time - this.lastTime) / 1000));
    this.lastTime = time;
    this.input.update();

    if (this.playing && !this.paused) this.update(delta, time);
    this.render(time / 1000);
    this.animationFrame = requestAnimationFrame(this.loop);
  };

  private update(delta: number, time: number): void {
    if (this.runtime.complete) {
      this.updateParticles(delta);
      this.updateRings(delta);
      this.screenFlash = Math.max(0, this.screenFlash - delta);
      if (this.transitionAt > 0 && time >= this.transitionAt) this.advanceStage();
      return;
    }

    this.runtime.elapsed = (time - this.stageStartedAt) / 1000;
    this.ledPulseClock += delta;
    this.trailClock += delta;
    this.screenFlash = Math.max(0, this.screenFlash - delta);

    if (this.input.consumeSwitch()) this.switchPlayer();
    const jump = this.input.consumeJump();
    const movement = this.input.movement();

    for (const player of Object.values(this.players)) {
      if (player.reachedExit) continue;
      const isActive = player.element === this.activeElement;
      if (isActive) {
        player.velocityX += (movement * MOVE_SPEED - player.velocityX) * Math.min(1, delta * 10);
        if (Math.abs(movement) > 0.04) player.facing = movement > 0 ? 1 : -1;
        if (jump && player.grounded) {
          player.velocityY = -JUMP_SPEED;
          player.grounded = false;
          this.audio.jump(player.element);
          this.callbacks.onSpeaker("점프 음");
          this.spawnBurst(player.x + player.width / 2, player.y + player.height, ELEMENT_COLORS[player.element].glow, 7);
        }
      } else {
        player.velocityX *= Math.max(0, 1 - delta * 10);
      }

      player.velocityY += GRAVITY * delta;
      player.animationTime += delta * (Math.abs(player.velocityX) > 18 ? 1 : 0.35);
      const wasGrounded = player.grounded;
      const landingVelocity = player.velocityY;
      this.movePlayer(player, delta);
      if (!wasGrounded && player.grounded && landingVelocity > 260) this.spawnLandingEffect(player);
      if (isActive && Math.abs(player.velocityX) > 90 && this.trailClock >= 0.045) {
        this.spawnTrail(player);
        this.trailClock = 0;
      }
      this.checkHazards(player);
      this.checkCheckpoint(player);
      this.checkRelics(player);
      this.checkPortal(player);
    }

    this.updateGimmicks(delta);
    this.updateParticles(delta);
    this.updateRings(delta);
    this.updateCamera(delta);
    this.updateMission();
    this.updateProgress();
    this.updateLedFeedback();

    if (this.players.fire.reachedExit && this.players.water.reachedExit) this.completeStage(time);
  }

  private movePlayer(player: PlayerState, delta: number): void {
    const solids = this.getSolids();

    player.x += player.velocityX * delta;
    player.x = clamp(player.x, 0, this.stage.worldWidth - player.width);
    for (const solid of solids) {
      if (!intersects(player, solid)) continue;
      if (player.velocityX > 0) player.x = solid.x - player.width;
      else if (player.velocityX < 0) player.x = solid.x + solid.width;
      player.velocityX = 0;
    }

    player.grounded = false;
    player.y += player.velocityY * delta;
    for (const solid of solids) {
      if (!intersects(player, solid)) continue;
      if (player.velocityY > 0) {
        player.y = solid.y - player.height;
        player.velocityY = 0;
        player.grounded = true;
      } else if (player.velocityY < 0) {
        player.y = solid.y + solid.height;
        player.velocityY = 0;
      }
    }

    if (player.y > VIEW_HEIGHT + 120) this.resetPlayer(player, "균형을 잃었습니다");
  }

  private getSolids(): Rect[] {
    const solids: Rect[] = [...this.stage.platforms];
    if (!this.runtime.gateAOpen) solids.push(this.gateRect("a"));
    if (this.stage.id > 1 && !this.runtime.gateBOpen) solids.push(this.gateRect("b"));
    return solids;
  }

  private gateRect(which: "a" | "b"): Rect {
    if (this.stage.id === 1) return { x: 915, y: 270, width: 76, height: 454 };
    if (this.stage.id === 2) {
      return which === "a"
        ? { x: 905, y: 270, width: 72, height: 454 }
        : { x: 1640, y: 330, width: 68, height: 394 };
    }
    return which === "a"
      ? { x: 920, y: 300, width: 72, height: 424 }
      : { x: 2030, y: 290, width: 74, height: 434 };
  }

  private checkHazards(player: PlayerState): void {
    for (const hazard of this.stage.hazards) {
      if (intersects(player, hazard) && player.element !== hazard.kind) {
        this.resetPlayer(player, `${hazard.kind === "fire" ? "불" : "물"}의 흐름은 ${player.element === "fire" ? "EMBER" : "TIDE"}에게 위험합니다`);
        return;
      }
    }
  }

  private checkCheckpoint(player: PlayerState): void {
    this.stage.checkpoints.forEach((checkpoint, index) => {
      const key = `${player.element}:${index}`;
      if (this.activatedCheckpoints.has(key)) return;
      const playerCenter = player.x + player.width / 2;
      const playerBottom = player.y + player.height;
      if (Math.abs(playerCenter - checkpoint.x) > 34 || Math.abs(playerBottom - checkpoint.y) > 135) return;
      this.activatedCheckpoints.add(key);
      player.spawnX = checkpoint.x - player.width / 2;
      player.spawnY = checkpoint.y - player.height;
      const color = ELEMENT_COLORS[player.element].glow;
      this.spawnBurst(checkpoint.x, checkpoint.y - 42, color, 14);
      this.spawnRing(checkpoint.x, checkpoint.y - 40, color, 74, 0.52, 3);
      this.audio.correct(0);
      this.callbacks.onToast(`${player.element === "fire" ? "EMBER" : "TIDE"} 체크포인트 활성화`);
    });
  }

  private checkRelics(player: PlayerState): void {
    this.stage.relics.forEach((relic, index) => {
      const key = `${this.stage.id}:${index}`;
      if (this.collectedRelics.has(key)) return;
      const hitbox = { x: relic.x - 18, y: relic.y - 18, width: 36, height: 36 };
      if (!intersects(player, hitbox)) return;
      this.collectedRelics.add(key);
      this.spawnBurst(relic.x, relic.y, "#fff4b0", 26);
      this.spawnRing(relic.x, relic.y, this.stage.theme.accent, 92, 0.62, 4);
      this.screenFlash = 0.12;
      this.screenFlashColor = "#fff4b0";
      this.audio.correct(this.collectedRelics.size - 1);
      this.callbacks.onSpeaker("기억 파편음");
      this.callbacks.onToast(`기억의 파편 ${this.collectedRelics.size}/${this.totalRelics()}`);
    });
  }

  private resetPlayer(player: PlayerState, reason: string): void {
    this.callbacks.onToast(reason);
    this.audio.wrong();
    this.callbacks.onSpeaker("경고음");
    this.setLed([100, 6, 8], "위험 감지");
    this.screenShake = 10;
    this.spawnBurst(player.x + player.width / 2, player.y + player.height / 2, "#ff435f", 18);
    this.spawnRing(player.x + player.width / 2, player.y + player.height / 2, "#ff435f", 110, 0.45, 5);
    this.screenFlash = 0.18;
    this.screenFlashColor = "#ff435f";
    player.x = clamp(player.spawnX, 20, this.stage.worldWidth - 100);
    player.y = Math.min(player.spawnY, 620);
    player.velocityX = 0;
    player.velocityY = 0;
  }

  private checkPortal(player: PlayerState): void {
    if (player.reachedExit) return;
    const portal = this.stage.portals.find((item) => item.element === player.element);
    if (!portal || !intersects(player, portal)) return;
    player.reachedExit = true;
    player.velocityX = 0;
    player.velocityY = 0;
    player.x = portal.x + portal.width / 2 - player.width / 2;
    player.y = portal.y + portal.height - player.height;
    this.spawnBurst(portal.x + portal.width / 2, portal.y + portal.height / 2, ELEMENT_COLORS[player.element].glow, 30);
    this.spawnRing(portal.x + portal.width / 2, portal.y + portal.height / 2, ELEMENT_COLORS[player.element].glow, 130, 0.72, 5);
    this.audio.correct(3);
    this.callbacks.onToast(`${player.element === "fire" ? "EMBER" : "TIDE"}의 문이 열렸습니다`);
    if (!this.players[this.otherElement(player.element)].reachedExit) this.activate(this.otherElement(player.element));
  }

  private updateGimmicks(delta: number): void {
    const furthestX = Math.max(this.players.fire.x, this.players.water.x);
    const sensor = this.input.state.env;

    if (this.stage.id === 1) {
      const nearIce = furthestX > 610 && furthestX < 1100;
      this.runtime.primaryProgress = applyThresholdProgress(
        this.runtime.primaryProgress,
        nearIce && sensor.temperature >= 30,
        delta,
        2.2,
        0.12,
      );
      if (this.runtime.primaryProgress >= 1 && !this.runtime.gateAOpen) this.openGate("a", "얼음이 물길로 녹아내렸습니다");
      return;
    }

    if (this.stage.id === 2) {
      this.runtime.primaryProgress = applyThresholdProgress(
        this.runtime.primaryProgress,
        furthestX > 520 && !this.runtime.gateAOpen && sensor.illuminance <= 18,
        delta,
        1.7,
        0.18,
      );
      if (this.runtime.primaryProgress >= 1 && !this.runtime.gateAOpen) this.openGate("a", "빛의 문이 잠들었습니다");
      if (this.runtime.gateAOpen && !this.runtime.gateBOpen && furthestX > 1120) this.consumePuzzleDirections();
      return;
    }

    if (!this.runtime.gateAOpen && furthestX > 560) this.consumePuzzleDirections();
    if (this.runtime.gateAOpen && furthestX > 1420 && !this.runtime.gateBOpen) {
      if (this.runtime.primaryProgress < 1) {
        this.runtime.primaryProgress = applyThresholdProgress(
          this.runtime.primaryProgress,
          sensor.temperature >= 27,
          delta,
          1.65,
          0.1,
        );
        if (this.runtime.primaryProgress >= 1) {
          this.audio.correct(1);
          this.callbacks.onToast("열 공명 완료 · 이제 빛을 가리세요");
        }
      } else {
        this.runtime.secondaryProgress = applyThresholdProgress(
          this.runtime.secondaryProgress,
          sensor.illuminance <= 18,
          delta,
          1.65,
          0.1,
        );
        if (this.runtime.secondaryProgress >= 1 && !this.runtime.gateBOpen) this.openGate("b", "공명 코어가 안정화되었습니다");
      }
    }
  }

  private consumePuzzleDirections(): void {
    const sequence = STAGE_SEQUENCES[this.stage.id as 2 | 3];
    if (!sequence) return;
    let inputDirection = this.input.consumeDirection();
    while (inputDirection) {
      const result = advanceSequence(sequence, this.runtime.puzzleIndex, inputDirection);
      this.runtime.puzzleIndex = result.index;
      if (result.correct) {
        this.audio.correct(result.index - 1);
        this.callbacks.onSpeaker("룬 공명음");
        this.spawnBurst(
          this.stage.id === 2 ? 1450 : 790,
          500,
          this.stage.theme.accent,
          9,
        );
      } else {
        this.runtime.puzzleMistakes += 1;
        this.audio.wrong();
        this.callbacks.onSpeaker("퍼즐 오류음");
      }
      if (result.complete) {
        this.openGate(this.stage.id === 2 ? "b" : "a", "모든 룬이 같은 박자로 빛납니다");
        break;
      }
      inputDirection = this.input.consumeDirection();
    }
  }

  private openGate(which: "a" | "b", message: string): void {
    if (which === "a") this.runtime.gateAOpen = true;
    else this.runtime.gateBOpen = true;
    const gate = this.gateRect(which);
    this.spawnBurst(gate.x + gate.width / 2, gate.y + gate.height / 2, this.stage.theme.accent, 42);
    this.spawnRing(gate.x + gate.width / 2, gate.y + gate.height / 2, this.stage.theme.accent, 180, 0.85, 6);
    this.screenFlash = 0.16;
    this.screenFlashColor = this.stage.theme.accent;
    this.callbacks.onToast(message);
    this.audio.correct(2);
    this.callbacks.onSpeaker("해제 음");
    this.setLed([8, 100, 64], "기믹 해제");
    this.updateMission(true);
  }

  private switchPlayer(): void {
    const next = this.otherElement(this.activeElement);
    if (this.players[next].reachedExit) return;
    this.activate(next);
    this.callbacks.onToast(next === "fire" ? "EMBER에게 공명합니다" : "TIDE에게 공명합니다");
  }

  private activate(element: ElementKind): void {
    this.activeElement = element;
    this.callbacks.onActiveElement(element);
    this.audio.switch(element);
    this.callbacks.onSpeaker("전환 음");
    this.setLed(ELEMENT_COLORS[element].rgb, element === "fire" ? "EMBER 활성" : "TIDE 활성");
    const player = this.players[element];
    this.spawnRing(player.x + player.width / 2, player.y + player.height / 2, ELEMENT_COLORS[element].glow, 100, 0.48, 4);
    this.screenFlash = 0.1;
    this.screenFlashColor = ELEMENT_COLORS[element].glow;
  }

  private otherElement(element: ElementKind): ElementKind {
    return element === "fire" ? "water" : "fire";
  }

  private updateCamera(delta: number): void {
    const active = this.players[this.activeElement];
    this.targetCameraX = clamp(active.x - VIEW_WIDTH * 0.36, 0, this.stage.worldWidth - VIEW_WIDTH);
    this.cameraX += (this.targetCameraX - this.cameraX) * Math.min(1, delta * 4.5);
    this.screenShake *= Math.max(0, 1 - delta * 12);
  }

  private missionIndex(): number {
    const furthest = Math.max(this.players.fire.x, this.players.water.x);
    if (this.stage.id === 1) {
      if (this.runtime.gateAOpen) return 2;
      return furthest > 610 ? 1 : 0;
    }
    if (!this.runtime.gateAOpen) return 0;
    if (!this.runtime.gateBOpen) return 1;
    return 2;
  }

  private updateMission(force = false): void {
    const index = this.missionIndex();
    if (!force && index === this.lastMissionIndex) return;
    this.lastMissionIndex = index;
    this.callbacks.onMission(index + 1, this.stage.objectiveNames[index], index === 2 && this.players.fire.reachedExit && this.players.water.reachedExit);
  }

  private updateProgress(): void {
    const furthest = Math.max(this.players.fire.x, this.players.water.x);
    const travel = clamp(furthest / (this.stage.worldWidth - 240), 0, 1);
    const gateScore = (this.runtime.gateAOpen ? 0.14 : 0) + (this.stage.id > 1 && this.runtime.gateBOpen ? 0.14 : 0);
    const portalScore = (this.players.fire.reachedExit ? 0.08 : 0) + (this.players.water.reachedExit ? 0.08 : 0);
    this.callbacks.onProgress(clamp(travel * (this.stage.id === 1 ? 0.78 : 0.58) + gateScore + portalScore, 0, 1));
  }

  private updateLedFeedback(): void {
    if (this.ledPulseClock < 0.65 || this.runtime.complete) return;
    this.ledPulseClock = 0;
    const mission = this.missionIndex();
    if (mission === 2) {
      this.setLed(ELEMENT_COLORS[this.activeElement].rgb, this.activeElement === "fire" ? "EMBER 활성" : "TIDE 활성");
      return;
    }
    const progress = this.stage.id === 3 && this.runtime.gateAOpen ? Math.max(this.runtime.primaryProgress, this.runtime.secondaryProgress) : this.runtime.primaryProgress;
    if (progress > 0.02) {
      this.setLed([Math.round(12 + progress * 68), Math.round(35 + progress * 65), Math.round(85 - progress * 24)], "기믹 진행 중");
    }
  }

  private setLed(color: [number, number, number], label: string): void {
    const signature = color.join(",");
    if (signature === this.lastLed) return;
    this.lastLed = signature;
    this.input.send({ type: "command", action: "led", color });
    this.callbacks.onLed(color, label);
  }

  private completeStage(time: number): void {
    this.runtime.complete = true;
    this.callbacks.onProgress(1);
    this.callbacks.onMission(3, "두 원소의 문이 모두 열렸습니다", true);
    this.setLed([100, 100, 100], "스테이지 완료");
    this.callbacks.onSpeaker("완료 멜로디");
    this.audio.stageClear();
    this.spawnBurst(this.cameraX + VIEW_WIDTH / 2, 350, "#ffffff", 80);
    this.transitionAt = time + 2500;
  }

  private advanceStage(): void {
    if (this.stageIndex < STAGES.length - 1) {
      this.loadStage(this.stageIndex + 1);
      return;
    }
    this.playing = false;
    this.transitionAt = 0;
    this.callbacks.onVictory({
      restarts: this.restarts,
      elapsed: (performance.now() - this.totalStartedAt) / 1000,
      relics: this.collectedRelics.size,
      totalRelics: this.totalRelics(),
    });
  }

  private totalRelics(): number {
    return STAGES.reduce((total, stage) => total + stage.relics.length, 0);
  }

  private spawnTrail(player: PlayerState): void {
    const color = ELEMENT_COLORS[player.element].glow;
    const life = 0.2 + Math.random() * 0.16;
    this.particles.push({
      x: player.x + player.width / 2 - player.facing * 22,
      y: player.y + player.height * (0.45 + Math.random() * 0.35),
      vx: -player.velocityX * 0.14 + (Math.random() - 0.5) * 22,
      vy: -12 - Math.random() * 26,
      life,
      maxLife: life,
      size: 2 + Math.random() * 3,
      color,
    });
  }

  private spawnLandingEffect(player: PlayerState): void {
    const color = ELEMENT_COLORS[player.element].glow;
    for (let index = 0; index < 10; index += 1) {
      const life = 0.28 + Math.random() * 0.25;
      this.particles.push({
        x: player.x + player.width / 2 + (Math.random() - 0.5) * 28,
        y: player.y + player.height - 3,
        vx: (Math.random() - 0.5) * 150,
        vy: -20 - Math.random() * 70,
        life,
        maxLife: life,
        size: 1.5 + Math.random() * 3.5,
        color,
      });
    }
    this.spawnRing(player.x + player.width / 2, player.y + player.height, color, 54, 0.3, 2);
  }

  private spawnBurst(x: number, y: number, color: string, count: number): void {
    for (let index = 0; index < count; index += 1) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 40 + Math.random() * 170;
      const life = 0.45 + Math.random() * 0.75;
      this.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 40,
        life,
        maxLife: life,
        size: 2 + Math.random() * 5,
        color,
      });
    }
  }

  private spawnRing(x: number, y: number, color: string, maxRadius: number, duration: number, width: number): void {
    this.rings.push({ x, y, radius: 3, maxRadius, life: duration, maxLife: duration, color, width });
  }

  private updateParticles(delta: number): void {
    for (const particle of this.particles) {
      particle.life -= delta;
      particle.x += particle.vx * delta;
      particle.y += particle.vy * delta;
      particle.vy += 150 * delta;
    }
    this.particles = this.particles.filter((particle) => particle.life > 0);
  }

  private updateRings(delta: number): void {
    for (const ring of this.rings) {
      ring.life -= delta;
      ring.radius += (ring.maxRadius - ring.radius) * Math.min(1, delta * 7);
    }
    this.rings = this.rings.filter((ring) => ring.life > 0);
  }

  private render(time: number): void {
    const context = this.context;
    context.clearRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
    context.save();
    const shakeX = this.screenShake > 0.2 ? (Math.random() - 0.5) * this.screenShake : 0;
    const shakeY = this.screenShake > 0.2 ? (Math.random() - 0.5) * this.screenShake : 0;
    context.translate(shakeX, shakeY);

    this.drawBackground(time);
    this.drawAmbientLayers(time);
    this.drawWorld(time);
    this.drawForeground(time);
    context.restore();
  }

  private drawBackground(time: number): void {
    const context = this.context;
    const gradient = context.createLinearGradient(0, 0, 0, VIEW_HEIGHT);
    gradient.addColorStop(0, this.stage.theme.skyTop);
    gradient.addColorStop(1, this.stage.theme.skyBottom);
    context.fillStyle = gradient;
    context.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    const image = this.backgrounds.get(this.stage.background);
    if (image?.complete && image.naturalWidth > 0) {
      const travel = this.stage.worldWidth <= VIEW_WIDTH ? 0 : this.cameraX / (this.stage.worldWidth - VIEW_WIDTH);
      const scale = Math.max(VIEW_WIDTH / image.naturalWidth, VIEW_HEIGHT / image.naturalHeight) * 1.14;
      const width = image.naturalWidth * scale;
      const height = image.naturalHeight * scale;
      const overflowX = Math.max(0, width - VIEW_WIDTH);
      context.globalAlpha = 0.88;
      context.drawImage(image, -overflowX * travel, (VIEW_HEIGHT - height) / 2, width, height);
      context.globalAlpha = 1;
    } else {
      this.drawFallbackBackdrop(time);
    }

    const haze = context.createLinearGradient(0, 360, 0, VIEW_HEIGHT);
    haze.addColorStop(0, "transparent");
    haze.addColorStop(1, `${this.stage.theme.fog}38`);
    context.fillStyle = haze;
    context.fillRect(0, 280, VIEW_WIDTH, VIEW_HEIGHT - 280);

    if (this.stage.id === 2 && this.input.state.env.illuminance <= 18) {
      context.fillStyle = `rgba(3, 4, 18, ${0.24 + this.runtime.primaryProgress * 0.32})`;
      context.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
    }
  }

  private drawFallbackBackdrop(time: number): void {
    const context = this.context;
    const parallax = this.cameraX * 0.12;
    context.globalAlpha = 0.28;
    for (let layer = 0; layer < 3; layer += 1) {
      context.beginPath();
      context.moveTo(0, VIEW_HEIGHT);
      for (let x = -180; x <= VIEW_WIDTH + 240; x += 180) {
        const worldX = x + parallax * (layer + 1);
        const height = 180 + layer * 72 + Math.sin(worldX * 0.006 + layer + time * 0.05) * 70;
        context.lineTo(x, VIEW_HEIGHT - height);
      }
      context.lineTo(VIEW_WIDTH, VIEW_HEIGHT);
      context.fillStyle = layer === 0 ? "#091724" : layer === 1 ? "#143047" : this.stage.theme.skyBottom;
      context.fill();
    }
    context.globalAlpha = 1;
  }

  private drawAmbientLayers(time: number): void {
    const context = this.context;
    context.save();
    context.globalCompositeOperation = "screen";
    for (let index = 0; index < 18; index += 1) {
      const x = ((index * 193 + time * (5 + (index % 3)) - this.cameraX * 0.04) % (VIEW_WIDTH + 160)) - 80;
      const y = 90 + ((index * 79) % 530) + Math.sin(time * 0.45 + index) * 12;
      const radius = 1.5 + (index % 4) * 0.7;
      context.globalAlpha = 0.18 + (index % 5) * 0.055;
      context.fillStyle = index % 2 ? this.stage.theme.accent : "#ffffff";
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.fill();
    }
    if (this.stage.id === 1) {
      for (let index = 0; index < 30; index += 1) {
        const x = ((index * 83 + time * (12 + (index % 5) * 3) - this.cameraX * 0.06) % (VIEW_WIDTH + 80)) - 40;
        const y = ((index * 127 + time * (34 + (index % 4) * 7)) % (VIEW_HEIGHT + 120)) - 80;
        context.globalAlpha = 0.18 + (index % 4) * 0.08;
        context.fillStyle = index % 5 === 0 ? this.stage.theme.accent : "#ffffff";
        context.beginPath();
        context.ellipse(x, y, 1.2 + (index % 3), 3 + (index % 4), -0.35, 0, Math.PI * 2);
        context.fill();
      }
    } else if (this.stage.id === 2) {
      for (let index = 0; index < 12; index += 1) {
        const x = ((index * 171 + time * (9 + (index % 3) * 2) - this.cameraX * 0.08) % (VIEW_WIDTH + 160)) - 80;
        const y = 130 + ((index * 97) % 520) + Math.sin(time * 0.7 + index) * 34;
        context.save();
        context.translate(x, y);
        context.rotate(Math.sin(time * 0.9 + index) * 0.65);
        context.globalAlpha = 0.12 + (index % 3) * 0.06;
        context.fillStyle = "#e8ddff";
        context.fillRect(-7, -10, 14, 20);
        context.strokeStyle = "rgba(65,42,97,.55)";
        context.lineWidth = 1;
        context.beginPath();
        context.moveTo(-3, -5);
        context.lineTo(4, -5);
        context.moveTo(-3, 0);
        context.lineTo(3, 0);
        context.stroke();
        context.restore();
      }
    } else {
      for (let index = 0; index < 24; index += 1) {
        const x = ((index * 109 - time * (22 + (index % 4) * 8) - this.cameraX * 0.05) % (VIEW_WIDTH + 120)) + 40;
        const y = 80 + ((index * 67 + time * 17) % 620);
        context.globalAlpha = 0.18 + (index % 5) * 0.07;
        context.strokeStyle = index % 3 === 0 ? "#ff9966" : this.stage.theme.accent;
        context.lineWidth = 1 + (index % 2);
        context.beginPath();
        context.moveTo(x, y);
        context.lineTo(x - 8 - (index % 4) * 4, y + 4);
        context.stroke();
      }
    }
    context.restore();
  }

  private drawWorld(time: number): void {
    const context = this.context;
    context.save();
    context.translate(-this.cameraX, 0);

    for (const decoration of this.stage.decorations.filter((item) => item.layer === "back")) this.drawMapDecoration(decoration, time);
    for (const platform of this.stage.platforms) this.drawPlatform(platform);
    for (const hazard of this.stage.hazards) this.drawHazard(hazard, time);
    for (const decoration of this.stage.decorations.filter((item) => item.layer === "front")) this.drawMapDecoration(decoration, time);
    this.drawCheckpoints(time);
    this.drawRelics(time);
    if (!this.runtime.gateAOpen) this.drawGate("a", time);
    if (this.stage.id > 1 && !this.runtime.gateBOpen) this.drawGate("b", time);
    // Sensor conditions are gameplay guidance, so they must stay readable above
    // the gate pillars they describe. The cards intentionally overlap those
    // pillars in stages 1 and 2.
    this.drawGimmickDevices(time);
    for (const portal of this.stage.portals) this.drawPortal(portal, time);
    for (const player of Object.values(this.players)) this.drawPlayer(player, time);
    this.drawParticles();
    this.drawRings();

    context.restore();
  }

  private drawMapDecoration(decoration: MapDecoration, time: number): void {
    if (decoration.x < this.cameraX - 160 || decoration.x > this.cameraX + VIEW_WIDTH + 160) return;
    const context = this.context;
    const direction = decoration.flip ? -1 : 1;
    context.save();
    context.translate(decoration.x, decoration.y);
    context.scale(direction * decoration.scale, decoration.scale);

    switch (decoration.kind) {
      case "crystal": {
        context.shadowColor = this.stage.theme.accent;
        context.shadowBlur = 20 + Math.sin(time * 2 + decoration.x) * 4;
        const crystal = (offset: number, height: number, width: number, alpha: number): void => {
          const gradient = context.createLinearGradient(offset, -height, offset, 0);
          gradient.addColorStop(0, `rgba(224,252,255,${alpha})`);
          gradient.addColorStop(0.45, this.stage.theme.accent);
          gradient.addColorStop(1, "rgba(18,67,94,.72)");
          context.fillStyle = gradient;
          context.beginPath();
          context.moveTo(offset, -height);
          context.lineTo(offset + width, -height * 0.22);
          context.lineTo(offset + width * 0.55, 0);
          context.lineTo(offset - width * 0.55, 0);
          context.lineTo(offset - width, -height * 0.22);
          context.closePath();
          context.fill();
          context.strokeStyle = "rgba(255,255,255,.4)";
          context.lineWidth = 1;
          context.stroke();
        };
        crystal(0, 74, 22, 0.92);
        crystal(-25, 48, 15, 0.64);
        crystal(27, 38, 13, 0.5);
        break;
      }
      case "lantern": {
        context.strokeStyle = "rgba(179,214,225,.52)";
        context.lineWidth = 4;
        context.beginPath();
        context.moveTo(0, 0);
        context.lineTo(0, -64);
        context.lineTo(14, -76);
        context.stroke();
        context.shadowColor = this.stage.theme.accent;
        context.shadowBlur = 24;
        context.fillStyle = this.stage.theme.accent;
        context.beginPath();
        context.arc(14, -73, 9 + Math.sin(time * 3 + decoration.x) * 1.2, 0, Math.PI * 2);
        context.fill();
        context.strokeStyle = "rgba(255,255,255,.55)";
        context.lineWidth = 2;
        context.strokeRect(5, -84, 18, 23);
        break;
      }
      case "rune-stone": {
        const gradient = context.createLinearGradient(0, -80, 0, 0);
        gradient.addColorStop(0, "#294d5c");
        gradient.addColorStop(1, "#0b2632");
        context.fillStyle = gradient;
        context.beginPath();
        context.moveTo(-23, 0);
        context.lineTo(-27, -60);
        context.lineTo(-13, -79);
        context.lineTo(18, -75);
        context.lineTo(27, -55);
        context.lineTo(22, 0);
        context.closePath();
        context.fill();
        context.strokeStyle = this.stage.theme.accent;
        context.shadowColor = this.stage.theme.accent;
        context.shadowBlur = 12;
        context.globalAlpha = 0.45 + Math.sin(time * 2.2 + decoration.x) * 0.12;
        context.lineWidth = 2;
        context.beginPath();
        context.moveTo(0, -62);
        context.lineTo(-10, -44);
        context.lineTo(0, -27);
        context.lineTo(11, -45);
        context.closePath();
        context.stroke();
        break;
      }
      case "banner": {
        context.strokeStyle = "rgba(204,190,234,.42)";
        context.lineWidth = 3;
        context.beginPath();
        context.moveTo(0, -18);
        context.lineTo(0, 116);
        context.stroke();
        const wave = Math.sin(time * 1.6 + decoration.x) * 5;
        const gradient = context.createLinearGradient(0, 0, 56, 100);
        gradient.addColorStop(0, "rgba(116,84,169,.84)");
        gradient.addColorStop(1, "rgba(31,22,63,.9)");
        context.fillStyle = gradient;
        context.beginPath();
        context.moveTo(0, 0);
        context.quadraticCurveTo(31 + wave, 10, 58, 3);
        context.lineTo(53 + wave, 88);
        context.lineTo(29, 108);
        context.lineTo(3, 89);
        context.closePath();
        context.fill();
        context.strokeStyle = "rgba(213,191,255,.44)";
        context.stroke();
        break;
      }
      case "book-stack": {
        const colors = ["#6f527e", "#334f78", "#8d5f5f", "#4a3868"];
        for (let index = 0; index < 4; index += 1) {
          const width = 38 + ((index * 11) % 19);
          const offset = index % 2 ? 5 : -3;
          context.fillStyle = colors[index];
          this.roundRect(context, offset - width / 2, -14 - index * 13, width, 11, 3);
          context.fill();
          context.fillStyle = "rgba(246,226,185,.45)";
          context.fillRect(offset - width / 2 + 5, -11 - index * 13, width - 10, 2);
        }
        break;
      }
      case "mirror": {
        context.shadowColor = this.stage.theme.accent;
        context.shadowBlur = 15;
        context.strokeStyle = "#a891d2";
        context.lineWidth = 7;
        context.beginPath();
        context.ellipse(0, -52, 28, 43, -0.12, 0, Math.PI * 2);
        context.stroke();
        const glass = context.createLinearGradient(-20, -80, 22, -25);
        glass.addColorStop(0, "rgba(255,255,255,.42)");
        glass.addColorStop(0.44, "rgba(133,103,196,.24)");
        glass.addColorStop(1, "rgba(61,40,101,.78)");
        context.fillStyle = glass;
        context.beginPath();
        context.ellipse(0, -52, 24, 39, -0.12, 0, Math.PI * 2);
        context.fill();
        context.strokeStyle = "#77648d";
        context.lineWidth = 5;
        context.beginPath();
        context.moveTo(0, -9);
        context.lineTo(0, 0);
        context.moveTo(-18, 0);
        context.lineTo(18, 0);
        context.stroke();
        break;
      }
      case "gear": {
        context.save();
        context.translate(0, -36);
        context.rotate(time * 0.22 * direction);
        context.strokeStyle = "rgba(107,224,200,.68)";
        context.fillStyle = "rgba(15,61,62,.82)";
        context.lineWidth = 6;
        for (let index = 0; index < 10; index += 1) {
          context.rotate(Math.PI / 5);
          context.fillRect(-5, -42, 10, 14);
        }
        context.beginPath();
        context.arc(0, 0, 31, 0, Math.PI * 2);
        context.fill();
        context.stroke();
        context.beginPath();
        context.arc(0, 0, 10, 0, Math.PI * 2);
        context.stroke();
        context.restore();
        break;
      }
      case "conduit": {
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = "rgba(25,48,52,.94)";
        context.lineWidth = 18;
        context.beginPath();
        context.moveTo(-45, 0);
        context.lineTo(-45, -42);
        context.quadraticCurveTo(-45, -63, -24, -63);
        context.lineTo(30, -63);
        context.lineTo(43, -85);
        context.stroke();
        context.strokeStyle = this.stage.theme.accent;
        context.shadowColor = this.stage.theme.accent;
        context.shadowBlur = 12;
        context.globalAlpha = 0.36 + Math.sin(time * 2.4 + decoration.x) * 0.14;
        context.lineWidth = 4;
        context.stroke();
        break;
      }
    }
    context.restore();
  }

  private drawCheckpoints(time: number): void {
    const context = this.context;
    this.stage.checkpoints.forEach((checkpoint, index) => {
      if (checkpoint.x < this.cameraX - 80 || checkpoint.x > this.cameraX + VIEW_WIDTH + 80) return;
      const fireActive = this.activatedCheckpoints.has(`fire:${index}`);
      const waterActive = this.activatedCheckpoints.has(`water:${index}`);
      context.save();
      context.translate(checkpoint.x, checkpoint.y);
      context.fillStyle = "rgba(6,20,29,.88)";
      context.fillRect(-18, -17, 36, 17);
      context.strokeStyle = "rgba(255,255,255,.18)";
      context.lineWidth = 3;
      context.beginPath();
      context.moveTo(0, -17);
      context.lineTo(0, -78);
      context.stroke();
      const orbGradient = context.createLinearGradient(-16, 0, 16, 0);
      orbGradient.addColorStop(0, fireActive ? ELEMENT_COLORS.fire.glow : "#26313a");
      orbGradient.addColorStop(0.5, fireActive || waterActive ? "#ffffff" : "#46515a");
      orbGradient.addColorStop(1, waterActive ? ELEMENT_COLORS.water.glow : "#26313a");
      context.fillStyle = orbGradient;
      context.shadowColor = fireActive || waterActive ? this.stage.theme.accent : "transparent";
      context.shadowBlur = fireActive || waterActive ? 22 + Math.sin(time * 4) * 4 : 0;
      context.beginPath();
      context.arc(0, -82, 14, 0, Math.PI * 2);
      context.fill();
      context.restore();
    });
  }

  private drawRelics(time: number): void {
    const context = this.context;
    this.stage.relics.forEach((relic, index) => {
      if (this.collectedRelics.has(`${this.stage.id}:${index}`)) return;
      if (relic.x < this.cameraX - 80 || relic.x > this.cameraX + VIEW_WIDTH + 80) return;
      const bob = Math.sin(time * 2.8 + index * 1.7) * 7;
      context.save();
      context.translate(relic.x, relic.y + bob);
      context.rotate(time * 0.8 + index);
      context.shadowColor = "#fff1a8";
      context.shadowBlur = 26;
      const gradient = context.createLinearGradient(-12, -18, 13, 19);
      gradient.addColorStop(0, "#ffffff");
      gradient.addColorStop(0.36, "#ffe98d");
      gradient.addColorStop(1, this.stage.theme.accent);
      context.fillStyle = gradient;
      context.beginPath();
      context.moveTo(0, -18);
      context.lineTo(13, 0);
      context.lineTo(0, 18);
      context.lineTo(-13, 0);
      context.closePath();
      context.fill();
      context.strokeStyle = "rgba(255,255,255,.8)";
      context.lineWidth = 2;
      context.stroke();
      context.restore();
      context.save();
      const beam = context.createLinearGradient(0, relic.y - 80, 0, relic.y + 42);
      beam.addColorStop(0, "transparent");
      beam.addColorStop(0.55, "rgba(255,241,168,.09)");
      beam.addColorStop(1, "transparent");
      context.fillStyle = beam;
      context.fillRect(relic.x - 12, relic.y - 80, 24, 122);
      context.restore();
    });
  }

  private drawPlatform(platform: Platform): void {
    if (platform.x + platform.width < this.cameraX - 80 || platform.x > this.cameraX + VIEW_WIDTH + 80) return;
    const context = this.context;
    const colors: Record<NonNullable<Platform["style"]>, [string, string, string]> = {
      stone: ["#1b3b50", "#0b2333", "#79d9e9"],
      ice: ["#4f91ae", "#15384c", "#b6f5ff"],
      archive: ["#463c67", "#211b3a", "#cab6ff"],
      core: ["#235a57", "#0a2b31", "#7ff5d2"],
    };
    const [top, bottom, edge] = colors[platform.style ?? "stone"];
    const gradient = context.createLinearGradient(0, platform.y, 0, platform.y + platform.height);
    gradient.addColorStop(0, top);
    gradient.addColorStop(0.16, top);
    gradient.addColorStop(1, bottom);
    context.fillStyle = gradient;
    context.fillRect(platform.x, platform.y, platform.width, platform.height);
    context.fillStyle = edge;
    context.globalAlpha = 0.52;
    context.fillRect(platform.x, platform.y, platform.width, 3);
    context.globalAlpha = 0.25;
    for (let x = platform.x + 16; x < platform.x + platform.width; x += 48) {
      context.fillRect(x, platform.y + 13, 2, Math.min(20, platform.height - 13));
    }
    context.globalAlpha = 1;
  }

  private drawHazard(hazard: Hazard, time: number): void {
    if (hazard.x + hazard.width < this.cameraX - 60 || hazard.x > this.cameraX + VIEW_WIDTH + 60) return;
    const context = this.context;
    const colors = ELEMENT_COLORS[hazard.kind];
    context.save();
    context.shadowBlur = 28;
    context.shadowColor = colors.glow;
    const gradient = context.createLinearGradient(0, hazard.y, 0, hazard.y + hazard.height);
    gradient.addColorStop(0, colors.glow);
    gradient.addColorStop(1, colors.main);
    context.fillStyle = gradient;
    context.beginPath();
    context.moveTo(hazard.x, hazard.y + 8);
    for (let x = 0; x <= hazard.width; x += 12) {
      context.lineTo(hazard.x + x, hazard.y + Math.sin(time * 4.2 + x * 0.08) * 5 + 7);
    }
    context.lineTo(hazard.x + hazard.width, hazard.y + hazard.height);
    context.lineTo(hazard.x, hazard.y + hazard.height);
    context.closePath();
    context.fill();
    context.restore();
  }

  private drawGate(which: "a" | "b", time: number): void {
    const gate = this.gateRect(which);
    if (gate.x + gate.width < this.cameraX - 80 || gate.x > this.cameraX + VIEW_WIDTH + 80) return;
    const context = this.context;
    const progress = which === "a" ? this.runtime.primaryProgress : this.runtime.secondaryProgress;
    context.save();
    context.globalAlpha = 1 - easeOutCubic(progress) * 0.55;
    context.shadowColor = this.stage.theme.accent;
    context.shadowBlur = 24 + Math.sin(time * 3) * 6;

    if (this.stage.id === 1) {
      const gradient = context.createLinearGradient(gate.x, gate.y, gate.x + gate.width, gate.y);
      gradient.addColorStop(0, "#68bcd9");
      gradient.addColorStop(0.5, "#d4fbff");
      gradient.addColorStop(1, "#2f7898");
      context.fillStyle = gradient;
      context.beginPath();
      context.moveTo(gate.x + 10, gate.y);
      context.lineTo(gate.x + gate.width - 8, gate.y + 14);
      context.lineTo(gate.x + gate.width, gate.y + gate.height);
      context.lineTo(gate.x, gate.y + gate.height);
      context.closePath();
      context.fill();
      context.strokeStyle = "rgba(255,255,255,.72)";
      context.lineWidth = 3;
      context.beginPath();
      context.moveTo(gate.x + 20, gate.y + 50);
      context.lineTo(gate.x + 55, gate.y + 140);
      context.lineTo(gate.x + 24, gate.y + 225);
      context.lineTo(gate.x + 48, gate.y + 330);
      context.stroke();
    } else {
      const gradient = context.createLinearGradient(gate.x, 0, gate.x + gate.width, 0);
      gradient.addColorStop(0, this.stage.id === 2 ? "#241d47" : "#123a3a");
      gradient.addColorStop(0.5, this.stage.theme.accent);
      gradient.addColorStop(1, this.stage.id === 2 ? "#241d47" : "#123a3a");
      context.fillStyle = gradient;
      context.fillRect(gate.x, gate.y, gate.width, gate.height);
      context.globalCompositeOperation = "screen";
      context.fillStyle = "rgba(255,255,255,.35)";
      for (let y = gate.y + 20; y < gate.y + gate.height; y += 42) context.fillRect(gate.x + 8, y, gate.width - 16, 2);
    }
    context.restore();
  }

  private drawGimmickDevices(time: number): void {
    const context = this.context;
    if (this.stage.id === 1) {
      this.drawSensorPrompt(845, 455, "♨", "30°C 이상 유지", this.runtime.primaryProgress, this.input.state.env.temperature >= 27);
      return;
    }

    if (this.stage.id === 2) {
      this.drawSensorPrompt(825, 430, "◐", "조도 18% 이하", this.runtime.primaryProgress, this.input.state.env.illuminance <= 18);
      this.drawSequenceDevice(1445, 520, STAGE_SEQUENCES[2], this.runtime.puzzleIndex, time);
      return;
    }

    this.drawSequenceDevice(790, 485, STAGE_SEQUENCES[3], this.runtime.puzzleIndex, time);
    const coreX = 1865;
    context.save();
    context.translate(coreX, 485);
    context.shadowBlur = 38;
    context.shadowColor = this.stage.theme.accent;
    context.strokeStyle = this.stage.theme.accent;
    context.lineWidth = 5;
    context.globalAlpha = 0.48 + Math.sin(time * 2.8) * 0.12;
    context.beginPath();
    context.arc(0, 0, 66, 0, Math.PI * 2);
    context.stroke();
    context.rotate(time * 0.25);
    context.setLineDash([14, 12]);
    context.beginPath();
    context.arc(0, 0, 88, 0, Math.PI * 2);
    context.stroke();
    context.setLineDash([]);
    context.globalAlpha = 1;
    const coreGradient = context.createRadialGradient(0, 0, 3, 0, 0, 48);
    coreGradient.addColorStop(0, "#ffffff");
    coreGradient.addColorStop(0.35, this.runtime.primaryProgress >= 1 ? "#71f5d2" : "#ff9a66");
    coreGradient.addColorStop(1, "rgba(116,243,206,0)");
    context.fillStyle = coreGradient;
    context.beginPath();
    context.arc(0, 0, 49, 0, Math.PI * 2);
    context.fill();
    context.restore();
    const coreProgress = this.runtime.primaryProgress < 1 ? this.runtime.primaryProgress : this.runtime.secondaryProgress;
    const coreActive = this.runtime.primaryProgress < 1 ? this.input.state.env.temperature >= 27 : this.input.state.env.illuminance <= 18;
    this.drawSensorPrompt(
      coreX - 90,
      360,
      this.runtime.primaryProgress < 1 ? "♨" : "◐",
      this.runtime.primaryProgress < 1 ? "열 공명" : "암전 안정화",
      coreProgress,
      coreActive,
    );
  }

  private drawSensorPrompt(x: number, y: number, icon: string, label: string, progress: number, active: boolean): void {
    const context = this.context;
    context.save();
    this.roundRect(context, x, y, 178, 72, 18);
    context.fillStyle = "rgba(4, 14, 25, .76)";
    context.fill();
    context.strokeStyle = active ? this.stage.theme.accent : "rgba(255,255,255,.2)";
    context.lineWidth = 2;
    context.stroke();
    context.fillStyle = active ? this.stage.theme.accent : "#ffffff";
    context.font = "700 25px system-ui";
    context.fillText(icon, x + 18, y + 32);
    context.fillStyle = "rgba(255,255,255,.65)";
    context.font = "600 12px system-ui";
    context.fillText(label, x + 52, y + 28);
    context.fillStyle = "rgba(255,255,255,.12)";
    this.roundRect(context, x + 52, y + 42, 104, 7, 4);
    context.fill();
    context.fillStyle = this.stage.theme.accent;
    this.roundRect(context, x + 52, y + 42, 104 * progress, 7, 4);
    context.fill();
    context.restore();
  }

  private drawSequenceDevice(x: number, y: number, sequence: readonly Direction[], index: number, time: number): void {
    const context = this.context;
    context.save();
    context.translate(x, y);
    context.shadowColor = this.stage.theme.accent;
    context.shadowBlur = 20;
    context.fillStyle = "rgba(5, 12, 24, .78)";
    this.roundRect(context, -sequence.length * 27 - 18, -38, sequence.length * 54 + 36, 76, 24);
    context.fill();
    context.shadowBlur = 0;
    sequence.forEach((direction, directionIndex) => {
      const cx = (directionIndex - (sequence.length - 1) / 2) * 54;
      const solved = directionIndex < index;
      context.fillStyle = solved ? this.stage.theme.accent : "rgba(255,255,255,.09)";
      context.beginPath();
      context.arc(cx, 0, 19 + (solved ? Math.sin(time * 4 + directionIndex) * 1.5 : 0), 0, Math.PI * 2);
      context.fill();
      context.fillStyle = solved ? "#07151f" : "rgba(255,255,255,.72)";
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.font = "700 18px system-ui";
      context.fillText(directionGlyph[direction], cx, 1);
    });
    context.restore();
  }

  private drawPortal(portal: Portal, time: number): void {
    if (portal.x + portal.width < this.cameraX - 100 || portal.x > this.cameraX + VIEW_WIDTH + 100) return;
    const context = this.context;
    const color = ELEMENT_COLORS[portal.element];
    const player = this.players[portal.element];
    context.save();
    context.translate(portal.x + portal.width / 2, portal.y + portal.height / 2);
    context.shadowColor = color.glow;
    context.shadowBlur = player.reachedExit ? 45 : 25;
    context.strokeStyle = color.main;
    context.lineWidth = 7;
    context.globalAlpha = 0.7 + Math.sin(time * 3 + (portal.element === "fire" ? 0 : 1.3)) * 0.18;
    context.beginPath();
    context.ellipse(0, 0, portal.width * 0.44, portal.height * 0.48, 0, 0, Math.PI * 2);
    context.stroke();
    context.lineWidth = 2;
    context.rotate(time * (portal.element === "fire" ? 0.35 : -0.35));
    context.setLineDash([8, 10]);
    context.beginPath();
    context.ellipse(0, 0, portal.width * 0.58, portal.height * 0.59, 0, 0, Math.PI * 2);
    context.stroke();
    context.setLineDash([]);
    context.globalAlpha = 1;
    context.fillStyle = color.glow;
    context.font = "700 20px system-ui";
    context.textAlign = "center";
    context.fillText(portal.element === "fire" ? "△" : "▽", 0, 7);
    context.restore();
  }

  private drawPlayer(player: PlayerState, time: number): void {
    if (player.x + player.width < this.cameraX - 90 || player.x > this.cameraX + VIEW_WIDTH + 90) return;
    const context = this.context;
    const color = ELEMENT_COLORS[player.element];
    const isActive = player.element === this.activeElement && !player.reachedExit;
    const bob = player.grounded ? Math.sin(player.animationTime * 7) * Math.min(2, Math.abs(player.velocityX) / 90) : 0;

    context.save();
    context.translate(player.x + player.width / 2, player.y + player.height / 2 + bob);
    context.scale(player.facing, 1);
    if (isActive) {
      context.shadowColor = color.glow;
      context.shadowBlur = 24;
    }

    if (this.spriteSheet.complete && this.spriteSheet.naturalWidth > 0) {
      const columns = 4;
      const rows = 2;
      const sourceWidth = this.spriteSheet.naturalWidth / columns;
      const sourceHeight = this.spriteSheet.naturalHeight / rows;
      const moving = Math.abs(player.velocityX) > 20;
      const frame = moving ? Math.floor(player.animationTime * 8) % columns : Math.floor(time * 1.6) % 2;
      const row = player.element === "fire" ? 0 : 1;
      context.drawImage(
        this.spriteSheet,
        frame * sourceWidth,
        row * sourceHeight,
        sourceWidth,
        sourceHeight,
        -43,
        -52,
        86,
        104,
      );
    } else {
      this.drawFallbackPlayer(player.element, time);
    }
    context.restore();

    if (isActive) {
      context.save();
      context.translate(player.x + player.width / 2, player.y - 16 + Math.sin(time * 4) * 3);
      context.fillStyle = "rgba(255,255,255,.95)";
      context.beginPath();
      context.moveTo(-7, -6);
      context.lineTo(7, -6);
      context.lineTo(0, 3);
      context.closePath();
      context.fill();
      context.restore();
    }
  }

  private drawFallbackPlayer(element: ElementKind, time: number): void {
    const context = this.context;
    const color = ELEMENT_COLORS[element];
    const gradient = context.createRadialGradient(-8, -16, 3, 0, 0, 42);
    gradient.addColorStop(0, color.glow);
    gradient.addColorStop(0.62, color.main);
    gradient.addColorStop(1, element === "fire" ? "#cc3546" : "#176ec4");
    context.fillStyle = gradient;
    context.beginPath();
    if (element === "fire") {
      context.moveTo(0, -48);
      context.bezierCurveTo(16, -32, 32, -18, 27, 10);
      context.bezierCurveTo(24, 33, 12, 40, 0, 40);
      context.bezierCurveTo(-22, 40, -31, 24, -27, 4);
      context.bezierCurveTo(-24, -12, -9, -21, 0, -48);
    } else {
      context.moveTo(0, -47);
      context.bezierCurveTo(10, -26, 29, -8, 28, 12);
      context.bezierCurveTo(27, 31, 15, 41, 0, 41);
      context.bezierCurveTo(-17, 41, -29, 29, -28, 11);
      context.bezierCurveTo(-27, -8, -8, -27, 0, -47);
    }
    context.fill();
    context.fillStyle = "#07131f";
    context.beginPath();
    context.arc(-9, -3, 4.5, 0, Math.PI * 2);
    context.arc(9, -3, 4.5, 0, Math.PI * 2);
    context.fill();
    context.strokeStyle = "rgba(255,255,255,.72)";
    context.lineWidth = 3;
    context.beginPath();
    context.arc(0, 7, 7, 0.15, Math.PI - 0.15);
    context.stroke();
    context.globalAlpha = 0.5 + Math.sin(time * 4) * 0.1;
    context.fillStyle = "#ffffff";
    context.beginPath();
    context.ellipse(-12, -19, 7, 12, -0.4, 0, Math.PI * 2);
    context.fill();
  }

  private drawParticles(): void {
    const context = this.context;
    context.save();
    context.globalCompositeOperation = "screen";
    for (const particle of this.particles) {
      context.globalAlpha = clamp(particle.life / particle.maxLife, 0, 1);
      context.fillStyle = particle.color;
      context.beginPath();
      context.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      context.fill();
    }
    context.restore();
  }

  private drawRings(): void {
    const context = this.context;
    context.save();
    context.globalCompositeOperation = "screen";
    for (const ring of this.rings) {
      const alpha = clamp(ring.life / ring.maxLife, 0, 1);
      context.globalAlpha = alpha * 0.72;
      context.strokeStyle = ring.color;
      context.shadowColor = ring.color;
      context.shadowBlur = 16;
      context.lineWidth = Math.max(0.5, ring.width * alpha);
      context.beginPath();
      context.ellipse(ring.x, ring.y, ring.radius, ring.radius * 0.42, 0, 0, Math.PI * 2);
      context.stroke();
    }
    context.restore();
  }

  private drawForeground(time: number): void {
    const context = this.context;
    this.drawForegroundSilhouettes(time);
    const vignette = context.createRadialGradient(VIEW_WIDTH / 2, VIEW_HEIGHT / 2, 260, VIEW_WIDTH / 2, VIEW_HEIGHT / 2, 880);
    vignette.addColorStop(0, "transparent");
    vignette.addColorStop(1, "rgba(0, 4, 12, .5)");
    context.fillStyle = vignette;
    context.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);

    if (!this.playing) {
      context.fillStyle = "rgba(2, 10, 18, .28)";
      context.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
    }

    context.save();
    context.globalAlpha = 0.08;
    context.fillStyle = "#ffffff";
    for (let y = (time * 10) % 4; y < VIEW_HEIGHT; y += 4) context.fillRect(0, y, VIEW_WIDTH, 1);
    context.restore();

    if (this.screenFlash > 0) {
      context.save();
      context.globalCompositeOperation = "screen";
      context.globalAlpha = Math.min(0.32, this.screenFlash * 1.8);
      context.fillStyle = this.screenFlashColor;
      context.fillRect(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
      context.restore();
    }
  }

  private drawForegroundSilhouettes(time: number): void {
    const context = this.context;
    context.save();
    context.globalAlpha = 0.48;
    if (this.stage.id === 1) {
      const ice = (x: number, height: number, flip: boolean): void => {
        context.save();
        context.translate(x, VIEW_HEIGHT);
        context.scale(flip ? -1 : 1, 1);
        const gradient = context.createLinearGradient(0, -height, 0, 0);
        gradient.addColorStop(0, "rgba(85,198,235,.3)");
        gradient.addColorStop(1, "rgba(1,16,29,.94)");
        context.fillStyle = gradient;
        context.beginPath();
        context.moveTo(0, 0);
        context.lineTo(34, -height);
        context.lineTo(69, -35);
        context.lineTo(102, -height * 0.64);
        context.lineTo(135, 0);
        context.closePath();
        context.fill();
        context.restore();
      };
      ice(-20, 255, false);
      ice(VIEW_WIDTH + 20, 290, true);
    } else if (this.stage.id === 2) {
      context.fillStyle = "rgba(8,5,20,.9)";
      context.fillRect(-24, 0, 62, VIEW_HEIGHT);
      context.fillRect(VIEW_WIDTH - 38, 0, 62, VIEW_HEIGHT);
      context.strokeStyle = "rgba(143,112,198,.28)";
      context.lineWidth = 4;
      for (const x of [31, VIEW_WIDTH - 31]) {
        context.beginPath();
        context.arc(x, 185, 34 + Math.sin(time * 0.8) * 2, 0, Math.PI * 2);
        context.stroke();
      }
    } else {
      context.strokeStyle = "rgba(2,18,20,.9)";
      context.lineWidth = 28;
      context.beginPath();
      context.moveTo(-20, 170);
      context.bezierCurveTo(180, 125, 165, 25, 365, -20);
      context.moveTo(VIEW_WIDTH + 20, 250);
      context.bezierCurveTo(VIEW_WIDTH - 180, 190, VIEW_WIDTH - 120, 55, VIEW_WIDTH - 330, -20);
      context.stroke();
      context.strokeStyle = "rgba(96,255,211,.14)";
      context.lineWidth = 3;
      context.stroke();
    }
    context.restore();
  }

  private roundRect(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number): void {
    const safeRadius = Math.min(radius, Math.abs(width) / 2, Math.abs(height) / 2);
    context.beginPath();
    context.roundRect(x, y, Math.max(0, width), Math.max(0, height), safeRadius);
  }
}
