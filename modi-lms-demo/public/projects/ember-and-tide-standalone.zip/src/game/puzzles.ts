import type { Direction } from "./types";

export interface SequenceResult {
  index: number;
  complete: boolean;
  correct: boolean;
}

export function advanceSequence(
  sequence: readonly Direction[],
  currentIndex: number,
  input: Direction,
): SequenceResult {
  if (sequence.length === 0) {
    return { index: 0, complete: true, correct: true };
  }

  const correct = sequence[currentIndex] === input;
  const nextIndex = correct ? currentIndex + 1 : sequence[0] === input ? 1 : 0;
  return {
    index: nextIndex,
    complete: nextIndex >= sequence.length,
    correct,
  };
}

export function applyThresholdProgress(
  progress: number,
  active: boolean,
  deltaSeconds: number,
  secondsRequired: number,
  decayRate = 0.35,
): number {
  const delta = active ? deltaSeconds / secondsRequired : -deltaSeconds * decayRate;
  return Math.min(1, Math.max(0, progress + delta));
}

export function imuToMovement(roll: number, deadzone = 6, maximum = 28): number {
  if (Math.abs(roll) <= deadzone) return 0;
  const sign = Math.sign(roll);
  const normalized = (Math.abs(roll) - deadzone) / (maximum - deadzone);
  return sign * Math.min(1, Math.max(0, normalized));
}

