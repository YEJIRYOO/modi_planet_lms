import { describe, expect, it } from "vitest";
import { STAGES } from "./stages";

describe("stage configuration", () => {
  it("ships exactly three complete stages", () => {
    expect(STAGES).toHaveLength(3);
    expect(STAGES.map((stage) => stage.id)).toEqual([1, 2, 3]);
  });

  it.each(STAGES)("stage $id has both exits and three objectives", (stage) => {
    expect(new Set(stage.portals.map((portal) => portal.element))).toEqual(new Set(["fire", "water"]));
    expect(stage.objectiveNames).toHaveLength(3);
    expect(stage.worldWidth).toBeGreaterThan(2400);
    for (const portal of stage.portals) {
      expect(portal.x + portal.width).toBeLessThanOrEqual(stage.worldWidth);
    }
  });

  it.each(STAGES)("stage $id has a complete exploration layer", (stage) => {
    expect(stage.decorations.length).toBeGreaterThanOrEqual(6);
    expect(stage.checkpoints).toHaveLength(3);
    expect(stage.relics).toHaveLength(4);

    for (const item of [...stage.checkpoints, ...stage.relics]) {
      expect(item.x).toBeGreaterThan(0);
      expect(item.x).toBeLessThan(stage.worldWidth);
      expect(item.y).toBeGreaterThan(0);
      expect(item.y).toBeLessThan(800);
    }
  });
});
