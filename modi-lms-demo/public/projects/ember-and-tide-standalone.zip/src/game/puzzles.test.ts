import { describe, expect, it } from "vitest";
import { advanceSequence, applyThresholdProgress, imuToMovement } from "./puzzles";

describe("advanceSequence", () => {
  const sequence = ["up", "right", "left"] as const;

  it("advances and completes a correct direction sequence", () => {
    expect(advanceSequence(sequence, 0, "up")).toEqual({ index: 1, complete: false, correct: true });
    expect(advanceSequence(sequence, 2, "left")).toEqual({ index: 3, complete: true, correct: true });
  });

  it("restarts while preserving a matching first direction", () => {
    expect(advanceSequence(sequence, 2, "up")).toEqual({ index: 1, complete: false, correct: false });
    expect(advanceSequence(sequence, 1, "down")).toEqual({ index: 0, complete: false, correct: false });
  });
});

describe("applyThresholdProgress", () => {
  it("fills to one and never exceeds its bounds", () => {
    expect(applyThresholdProgress(0, true, 3, 2)).toBe(1);
    expect(applyThresholdProgress(0, false, 10, 2)).toBe(0);
  });
});

describe("imuToMovement", () => {
  it("uses a deadzone and normalizes tilt", () => {
    expect(imuToMovement(5)).toBe(0);
    expect(imuToMovement(-28)).toBe(-1);
    expect(imuToMovement(17)).toBeCloseTo(0.5);
  });
});

