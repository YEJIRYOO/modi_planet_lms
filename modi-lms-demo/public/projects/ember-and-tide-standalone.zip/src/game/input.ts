import { imuToMovement } from "./puzzles";
import type {
  BridgeCommand,
  CalibrationState,
  Direction,
  HardwareState,
  ModuleConnections,
} from "./types";

type StateListener = (state: HardwareState) => void;
type ConnectionListener = (connected: boolean) => void;

const allModules = (value: boolean): ModuleConnections => ({
  imu: value,
  joystick: value,
  env: value,
  button: value,
  led: value,
  speaker: value,
});

const initialCalibration = (): CalibrationState => ({
  available: false,
  required: false,
  active: false,
  calibrated: false,
  phase: "idle",
  sampleCount: 0,
  sampleReady: false,
  error: "",
  imuAxis: "x",
  imuSign: 1,
  joystickAxis: "x",
  joystickSign: 1,
});

const initialState = (): HardwareState => ({
  connected: false,
  source: "simulator",
  modules: allModules(true),
  calibration: { ...initialCalibration(), calibrated: true, phase: "complete" },
  imu: { roll: 0, pitch: 0, yaw: 0 },
  joystick: { x: 0, y: 0, direction: "origin" },
  env: { temperature: 24, illuminance: 72, humidity: 46, volume: 0 },
  button: { pressed: false, clicked: false, doubleClicked: false },
  timestamp: Date.now(),
});

function isDirection(value: unknown): value is Direction | "origin" {
  return ["up", "down", "left", "right", "origin"].includes(String(value));
}

export class ModiInput {
  state = initialState();
  private socket: WebSocket | null = null;
  private reconnectTimer: number | undefined;
  private listeners = new Set<StateListener>();
  private connectionListeners = new Set<ConnectionListener>();
  private keys = new Set<string>();
  private jumpRequested = false;
  private switchRequested = false;
  private directionQueue: Direction[] = [];
  private lastHardwareDirection: Direction | "origin" = "origin";
  private lastHardwareButton = false;
  private lastHardwareClick = false;
  private lastDoubleClick = false;
  private simulatorOverrideUntil = 0;
  private simulationHeat = false;
  private simulationDark = false;
  private simulationRoll = 0;
  private calibrating = false;
  private destroyed = false;

  constructor(private readonly url = "ws://127.0.0.1:8765") {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.connect();
  }

  subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  onConnection(listener: ConnectionListener): () => void {
    this.connectionListeners.add(listener);
    listener(this.state.connected);
    return () => this.connectionListeners.delete(listener);
  }

  update(): void {
    if (this.state.source === "hardware" && Date.now() > this.simulatorOverrideUntil) return;

    const keyboardRoll = this.keys.has("KeyA") ? -28 : this.keys.has("KeyD") ? 28 : 0;
    this.state.imu.roll = keyboardRoll || this.simulationRoll;
    this.state.env.temperature = this.simulationHeat || this.keys.has("KeyH") ? 34 : 24;
    this.state.env.illuminance = this.simulationDark || this.keys.has("KeyL") ? 4 : 72;
    this.state.timestamp = Date.now();
    this.emit();
  }

  movement(): number {
    return imuToMovement(this.state.imu.roll);
  }

  consumeJump(): boolean {
    const value = this.jumpRequested;
    this.jumpRequested = false;
    return value;
  }

  consumeSwitch(): boolean {
    const value = this.switchRequested;
    this.switchRequested = false;
    return value;
  }

  consumeDirection(): Direction | undefined {
    return this.directionQueue.shift();
  }

  setSimulationRoll(value: number): void {
    this.useSimulator();
    this.simulationRoll = Math.max(-35, Math.min(35, value));
    this.state.imu.roll = this.simulationRoll;
    this.emit();
  }

  setSimulationHeat(active: boolean): void {
    this.useSimulator();
    this.simulationHeat = active;
    this.state.env.temperature = active ? 34 : 24;
    this.emit();
  }

  setSimulationDark(active: boolean): void {
    this.useSimulator();
    this.simulationDark = active;
    this.state.env.illuminance = active ? 4 : 72;
    this.emit();
  }

  pressSimulationButton(): void {
    this.useSimulator();
    this.jumpRequested = true;
    this.state.button.pressed = true;
    this.emit();
    window.setTimeout(() => {
      this.state.button.pressed = false;
      this.emit();
    }, 140);
  }

  switchSimulationPlayer(): void {
    this.useSimulator();
    this.switchRequested = true;
    this.state.button.doubleClicked = true;
    this.emit();
    window.setTimeout(() => {
      this.state.button.doubleClicked = false;
      this.emit();
    }, 160);
  }

  pushSimulationDirection(direction: Direction | "origin"): void {
    this.useSimulator();
    const axes: Record<Direction | "origin", [number, number]> = {
      up: [0, 100],
      down: [0, -100],
      left: [-100, 0],
      right: [100, 0],
      origin: [0, 0],
    };
    const [x, y] = axes[direction];
    this.state.joystick = { x, y, direction };
    if (direction !== "origin") this.directionQueue.push(direction);
    this.emit();
  }

  send(command: BridgeCommand): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify(command));
    }
  }

  calibrate(operation: "begin" | "capture" | "reset" | "cancel"): void {
    this.calibrating = operation !== "cancel";
    this.clearTransientInputs();
    this.send({ type: "command", action: "calibrate", operation });
  }

  finishCalibration(): void {
    this.calibrating = false;
    this.clearTransientInputs();
  }

  private clearTransientInputs(): void {
    this.jumpRequested = false;
    this.switchRequested = false;
    this.directionQueue.length = 0;
    this.lastHardwareDirection = "origin";
    this.lastHardwareButton = false;
    this.lastHardwareClick = false;
    this.lastDoubleClick = false;
  }

  destroy(): void {
    this.destroyed = true;
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.clearTimeout(this.reconnectTimer);
    this.socket?.close();
  }

  private connect(): void {
    if (this.destroyed) return;
    try {
      this.socket = new WebSocket(this.url);
    } catch {
      this.scheduleReconnect();
      return;
    }

    this.socket.addEventListener("open", () => this.notifyConnection(true));
    this.socket.addEventListener("message", (event) => this.handleMessage(event.data));
    this.socket.addEventListener("close", () => {
      this.notifyConnection(false);
      this.scheduleReconnect();
    });
    this.socket.addEventListener("error", () => this.socket?.close());
  }

  private scheduleReconnect(): void {
    window.clearTimeout(this.reconnectTimer);
    this.reconnectTimer = window.setTimeout(() => this.connect(), 2200);
  }

  private handleMessage(raw: unknown): void {
    if (typeof raw !== "string") return;
    let data: Record<string, unknown>;
    try {
      data = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return;
    }
    if (data.type !== "telemetry") return;

    const telemetry = data as unknown as Partial<HardwareState>;
    const joystick = telemetry.joystick;
    const button = telemetry.button;
    const direction = joystick && isDirection(joystick.direction) ? joystick.direction : "origin";
    const calibration = { ...initialCalibration(), ...telemetry.calibration };
    const isCalibrating = this.calibrating || calibration.active;

    if (!isCalibrating && direction !== "origin" && direction !== this.lastHardwareDirection) {
      this.directionQueue.push(direction);
    }
    this.lastHardwareDirection = isCalibrating ? "origin" : direction;

    const pressed = Boolean(button?.pressed);
    const clicked = Boolean(button?.clicked);
    if (!isCalibrating && ((pressed && !this.lastHardwareButton) || (clicked && !this.lastHardwareClick))) {
      this.jumpRequested = true;
    }
    if (!isCalibrating && button?.doubleClicked && !this.lastDoubleClick) this.switchRequested = true;
    this.lastHardwareButton = pressed;
    this.lastHardwareClick = clicked;
    this.lastDoubleClick = Boolean(button?.doubleClicked);

    if (Date.now() < this.simulatorOverrideUntil) return;
    this.state = {
      ...initialState(),
      ...telemetry,
      connected: true,
      source: "hardware",
      modules: { ...allModules(false), ...telemetry.modules },
      calibration,
      imu: { ...initialState().imu, ...telemetry.imu },
      joystick: { ...initialState().joystick, ...telemetry.joystick, direction },
      env: { ...initialState().env, ...telemetry.env },
      button: { ...initialState().button, ...telemetry.button },
      timestamp: typeof telemetry.timestamp === "number" ? telemetry.timestamp : Date.now(),
    };
    this.emit();
  }

  private useSimulator(): void {
    this.simulatorOverrideUntil = Date.now() + 5000;
    this.state.source = "simulator";
    this.state.modules = allModules(true);
  }

  private notifyConnection(connected: boolean): void {
    if (!connected && this.state.source === "hardware") {
      this.state = initialState();
      this.emit();
    }
    for (const listener of this.connectionListeners) listener(connected);
  }

  private emit(): void {
    for (const listener of this.listeners) listener(this.state);
  }

  private onKeyDown = (event: KeyboardEvent): void => {
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.code)) {
      event.preventDefault();
    }
    if (event.repeat && !["KeyA", "KeyD", "KeyH", "KeyL"].includes(event.code)) return;
    this.keys.add(event.code);
    if (event.code === "Space" || event.code === "KeyW") {
      this.jumpRequested = true;
      this.state.button.pressed = true;
    }
    if (event.code === "Tab") {
      event.preventDefault();
      this.switchRequested = true;
    }
    const directionByCode: Partial<Record<string, Direction>> = {
      ArrowUp: "up",
      ArrowDown: "down",
      ArrowLeft: "left",
      ArrowRight: "right",
    };
    const direction = directionByCode[event.code];
    if (direction) this.pushSimulationDirection(direction);
    if (["KeyA", "KeyD", "KeyH", "KeyL"].includes(event.code)) this.useSimulator();
  };

  private onKeyUp = (event: KeyboardEvent): void => {
    this.keys.delete(event.code);
    if (event.code === "Space" || event.code === "KeyW") this.state.button.pressed = false;
    if (event.code.startsWith("Arrow")) this.pushSimulationDirection("origin");
  };

  private onBlur = (): void => {
    this.keys.clear();
    this.simulationHeat = false;
    this.simulationDark = false;
    this.state.button.pressed = false;
  };
}
