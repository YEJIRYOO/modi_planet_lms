export const GRAVITY = 1280;
export const MOVE_SPEED = 300;
export const JUMP_SPEED = 620;

export function maximumJumpHeight(jumpSpeed = JUMP_SPEED, gravity = GRAVITY): number {
  return (jumpSpeed * jumpSpeed) / (2 * gravity);
}

export function maximumJumpDistance(
  moveSpeed = MOVE_SPEED,
  jumpSpeed = JUMP_SPEED,
  gravity = GRAVITY,
): number {
  return moveSpeed * ((2 * jumpSpeed) / gravity);
}

