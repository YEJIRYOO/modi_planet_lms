import type { ElementKind } from "./types";
import type { ModiInput } from "./input";

export class GameAudio {
  private context: AudioContext | null = null;
  private master: GainNode | null = null;

  constructor(private readonly input: ModiInput) {}

  unlock(): void {
    if (!this.context) {
      this.context = new AudioContext();
      this.master = this.context.createGain();
      this.master.gain.value = 0.18;
      this.master.connect(this.context.destination);
    }
    void this.context.resume();
  }

  tone(frequency: number, duration = 0.11, hardwareVolume = 55): void {
    this.unlock();
    if (!this.context || !this.master) return;
    const now = this.context.currentTime;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(frequency, now);
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.75, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
    oscillator.connect(gain);
    gain.connect(this.master);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.02);
    this.input.send({
      type: "command",
      action: "tone",
      frequency: Math.round(frequency),
      volume: hardwareVolume,
      duration: Math.round(duration * 1000),
    });
  }

  jump(element: ElementKind): void {
    this.tone(element === "fire" ? 523.25 : 659.25, 0.09, 42);
  }

  switch(element: ElementKind): void {
    this.tone(element === "fire" ? 392 : 587.33, 0.14, 48);
  }

  correct(index: number): void {
    this.tone([523.25, 659.25, 783.99, 1046.5][index % 4] ?? 659.25, 0.13, 58);
  }

  wrong(): void {
    this.tone(174.61, 0.18, 35);
  }

  stageClear(): void {
    this.unlock();
    [523.25, 659.25, 783.99, 1046.5].forEach((frequency, index) => {
      window.setTimeout(() => this.tone(frequency, 0.25, 68), index * 150);
    });
    this.input.send({ type: "command", action: "music", name: "Success", volume: 72 });
  }
}

