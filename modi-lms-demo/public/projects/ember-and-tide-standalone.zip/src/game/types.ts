export type ElementKind = "fire" | "water";
export type Direction = "up" | "down" | "left" | "right";

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Platform extends Rect {
  style?: "stone" | "ice" | "archive" | "core";
}

export interface Hazard extends Rect {
  kind: ElementKind;
}

export interface Portal extends Rect {
  element: ElementKind;
}

export type DecorationKind =
  | "crystal"
  | "lantern"
  | "rune-stone"
  | "banner"
  | "book-stack"
  | "mirror"
  | "gear"
  | "conduit";

export interface MapDecoration {
  kind: DecorationKind;
  x: number;
  y: number;
  scale: number;
  layer: "back" | "front";
  flip?: boolean;
}

export interface Checkpoint {
  x: number;
  y: number;
}

export interface Relic {
  x: number;
  y: number;
}

export interface StageConfig {
  id: number;
  title: string;
  subtitle: string;
  background: string;
  worldWidth: number;
  starts: Record<ElementKind, { x: number; y: number }>;
  platforms: Platform[];
  hazards: Hazard[];
  portals: Portal[];
  decorations: MapDecoration[];
  checkpoints: Checkpoint[];
  relics: Relic[];
  objectiveNames: string[];
  theme: {
    skyTop: string;
    skyBottom: string;
    fog: string;
    accent: string;
  };
}

export interface PlayerState {
  element: ElementKind;
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  grounded: boolean;
  facing: 1 | -1;
  reachedExit: boolean;
  spawnX: number;
  spawnY: number;
  animationTime: number;
}

export interface ModuleConnections {
  imu: boolean;
  joystick: boolean;
  env: boolean;
  button: boolean;
  led: boolean;
  speaker: boolean;
}

export type CalibrationPhase = "idle" | "neutral" | "imu_right" | "joystick_right" | "complete";

export interface CalibrationState {
  available: boolean;
  required: boolean;
  active: boolean;
  calibrated: boolean;
  phase: CalibrationPhase;
  sampleCount: number;
  sampleReady: boolean;
  error: string;
  imuAxis: "x" | "y";
  imuSign: -1 | 1;
  joystickAxis: "x" | "y";
  joystickSign: -1 | 1;
}

export interface HardwareState {
  connected: boolean;
  source: "hardware" | "simulator";
  modules: ModuleConnections;
  calibration: CalibrationState;
  imu: { roll: number; pitch: number; yaw: number };
  joystick: { x: number; y: number; direction: Direction | "origin" };
  env: { temperature: number; illuminance: number; humidity: number; volume: number };
  button: { pressed: boolean; clicked: boolean; doubleClicked: boolean };
  timestamp: number;
}

export interface BridgeCommand {
  type: "command";
  action: "led" | "tone" | "music" | "stop" | "calibrate";
  color?: [number, number, number];
  frequency?: number;
  volume?: number;
  duration?: number;
  name?: string;
  operation?: "begin" | "capture" | "reset" | "cancel";
}

export interface StageRuntime {
  primaryProgress: number;
  secondaryProgress: number;
  puzzleIndex: number;
  puzzleMistakes: number;
  gateAOpen: boolean;
  gateBOpen: boolean;
  complete: boolean;
  elapsed: number;
}
