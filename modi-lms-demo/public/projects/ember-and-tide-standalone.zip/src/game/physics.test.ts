import { describe, expect, it } from "vitest";
import { maximumJumpDistance, maximumJumpHeight } from "./physics";
import { STAGES } from "./stages";

function largestRequiredRise(stageIndex: number): number {
  const platforms = STAGES[stageIndex].platforms;
  const floor = platforms.find((platform) => platform.x === 0);
  const route = platforms.filter((platform) => platform !== floor).sort((a, b) => a.x - b.x);
  let previousHeight = floor?.y ?? 724;
  let largestRise = 0;
  for (const platform of route) {
    largestRise = Math.max(largestRise, previousHeight - platform.y);
    previousHeight = platform.y;
  }
  return largestRise;
}

describe("platform reachability", () => {
  it("keeps vertical clearance above every intended stage route", () => {
    const jumpHeight = maximumJumpHeight();
    for (let stageIndex = 0; stageIndex < STAGES.length; stageIndex += 1) {
      expect(jumpHeight - largestRequiredRise(stageIndex)).toBeGreaterThanOrEqual(20);
    }
  });

  it("keeps enough horizontal travel for the widest designed gap", () => {
    expect(maximumJumpDistance()).toBeGreaterThan(280);
  });
});

