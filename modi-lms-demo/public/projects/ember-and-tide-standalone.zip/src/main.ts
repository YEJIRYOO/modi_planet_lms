import "./style.css";
import { ElementGame } from "./game/game";
import { ModiInput } from "./game/input";
import type { CalibrationPhase, ElementKind, HardwareState, StageConfig } from "./game/types";

function element<T extends HTMLElement>(selector: string): T {
  const found = document.querySelector<T>(selector);
  if (!found) throw new Error(`필수 UI 요소가 없습니다: ${selector}`);
  return found;
}

const canvas = element<HTMLCanvasElement>("#game-canvas");
const startScreen = element<HTMLElement>("#start-screen");
const victoryScreen = element<HTMLElement>("#victory-screen");
const topHud = element<HTMLElement>("#top-hud");
const moduleDock = element<HTMLElement>("#module-dock");
const missionCard = element<HTMLElement>("#mission-card");
const simulatorPanel = element<HTMLElement>("#simulator-panel");
const guideModal = element<HTMLElement>("#guide-modal");
const calibrationModal = element<HTMLElement>("#calibration-modal");
const pauseModal = element<HTMLElement>("#pause-modal");
const stageIntro = element<HTMLElement>("#stage-intro");
const toast = element<HTMLElement>("#toast");
const input = new ModiInput(import.meta.env.VITE_MODI_WS_URL || "ws://127.0.0.1:8765");

let toastTimer = 0;
let introTimer = 0;
let latestState: HardwareState | null = null;
let calibrationIntent: "start" | "resume" = "start";
let calibrationBeginRequested = false;
let autoCalibrationOffered = false;

function setGameplayUi(visible: boolean): void {
  topHud.classList.toggle("is-visible", visible);
  moduleDock.classList.toggle("is-visible", visible);
  missionCard.classList.toggle("is-visible", visible);
}

function showToast(message: string): void {
  toast.textContent = message;
  toast.classList.add("is-visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 2200);
}

function showStageIntro(stage: StageConfig): void {
  element("#stage-kicker").textContent = `STAGE ${String(stage.id).padStart(2, "0")}`;
  element("#stage-title").textContent = stage.title;
  element("#stage-subtitle").textContent = stage.subtitle;
  stageIntro.classList.add("is-visible");
  window.clearTimeout(introTimer);
  introTimer = window.setTimeout(() => stageIntro.classList.remove("is-visible"), 2300);
}

function updateModuleDock(state: HardwareState): void {
  element("#imu-value").textContent = `${state.imu.roll.toFixed(1)}°`;
  element("#joystick-value").textContent = `${Math.round(state.joystick.x)} · ${Math.round(state.joystick.y)}`;
  element("#env-value").textContent = `${Math.round(state.env.temperature)}°C · ${Math.round(state.env.illuminance)}%`;
  element("#button-value").textContent = state.button.doubleClicked ? "더블클릭" : state.button.pressed ? "눌림" : "대기";

  const moduleNames = ["imu", "joystick", "env", "button", "led", "speaker"] as const;
  for (const name of moduleNames) {
    const card = element<HTMLElement>(`.module-card[data-module="${name}"]`);
    card.classList.toggle("is-connected", state.source === "hardware" && state.modules[name]);
    card.classList.toggle("is-simulated", state.source === "simulator");
    card.classList.toggle("is-active", name === "button" && state.button.pressed);
  }

  const hardware = state.source === "hardware";
  element("#dock-status-dot").classList.toggle("is-online", hardware);
  const calibrationButton = element<HTMLButtonElement>("#calibration-open");
  calibrationButton.disabled = !hardware || !state.modules.imu || !state.modules.joystick;
  calibrationButton.classList.toggle("is-required", hardware && state.calibration.required);
  calibrationButton.textContent = state.calibration.calibrated ? "다시 맞추기" : "방향 맞추기";
  element("#hardware-hint").textContent = hardware
    ? state.calibration.calibrated
      ? "IMU와 조이스틱 방향이 동기화되었습니다."
      : "플레이 전에 IMU와 조이스틱 방향을 맞춰 주세요."
    : "브리지를 실행하면 실물 모듈로 자동 전환됩니다.";
}

const calibrationOrder: CalibrationPhase[] = ["neutral", "imu_right", "joystick_right"];

function hasDirectionModules(state: HardwareState | null): state is HardwareState {
  return Boolean(
    state && state.source === "hardware" && state.modules.imu && state.modules.joystick,
  );
}

function updateStartState(state: HardwareState): void {
  const copy = element("#start-connection");
  const startButton = element<HTMLButtonElement>("#start-button");
  const hardware = state.source === "hardware";
  if (!hardware) {
    copy.innerHTML = "<span></span> 시뮬레이터 준비됨";
    startButton.textContent = "탐험 시작";
    return;
  }
  if (!state.modules.imu || !state.modules.joystick) {
    copy.innerHTML = "<span class=\"is-online\"></span> IMU · JOYSTICK 연결 대기";
    startButton.textContent = "모듈 확인";
    return;
  }
  if (state.calibration.calibrated) {
    copy.innerHTML = "<span class=\"is-online\"></span> 방향 동기화 완료";
    startButton.textContent = "탐험 시작";
    return;
  }
  copy.innerHTML = "<span class=\"is-online\"></span> 방향 동기화 필요";
  startButton.textContent = "컨트롤러 맞추기";
}

function renderCalibration(state: HardwareState | null): void {
  if (!calibrationModal.classList.contains("is-visible")) return;
  const action = element<HTMLButtonElement>("#calibration-action");
  const cancel = element<HTMLButtonElement>("#calibration-cancel");
  const title = element("#calibration-title");
  const copy = element("#calibration-copy");
  const status = element("#calibration-status");
  const stepLabel = element("#calibration-step");
  const imuVisual = element("#calibration-imu");
  const joystickVisual = element("#calibration-joystick");
  const available = hasDirectionModules(state);
  const phase = state?.calibration.phase ?? "idle";
  const phaseIndex = calibrationOrder.indexOf(phase);

  element<HTMLOutputElement>("#calibration-imu-value").value = state
    ? `${state.imu.roll.toFixed(1)}°`
    : "0.0°";
  element<HTMLOutputElement>("#calibration-joystick-value").value = state
    ? `${Math.round(state.joystick.x)} · ${Math.round(state.joystick.y)}`
    : "0 · 0";

  imuVisual.classList.toggle("is-target", phase === "neutral" || phase === "imu_right" || phase === "complete");
  joystickVisual.classList.toggle(
    "is-target",
    phase === "neutral" || phase === "joystick_right" || phase === "complete",
  );

  document.querySelectorAll<HTMLElement>("[data-sync-step]").forEach((item, index) => {
    item.classList.toggle("is-active", index === phaseIndex);
    item.classList.toggle("is-complete", phase === "complete" || (phaseIndex >= 0 && index < phaseIndex));
  });

  status.classList.toggle("is-error", Boolean(state?.calibration.error));
  cancel.hidden = phase === "complete";

  if (!available) {
    title.textContent = "두 모듈을 연결하세요";
    copy.textContent = "IMU와 JOYSTICK이 모두 확인되면 방향 동기화를 시작합니다.";
    stepLabel.textContent = "연결 대기";
    status.textContent = "네트워크 모듈에 IMU와 JOYSTICK을 연결해 주세요.";
    action.textContent = "연결 대기";
    action.disabled = true;
    return;
  }

  if (phase === "complete") {
    title.textContent = "오른쪽이 하나로 맞았습니다";
    copy.textContent = "IMU 기울기와 조이스틱 입력이 게임 화면 방향으로 정렬되었습니다.";
    stepLabel.textContent = "완료";
    status.textContent = `IMU ${state.calibration.imuAxis.toUpperCase()}축 · JOYSTICK ${state.calibration.joystickAxis.toUpperCase()}축`;
    action.textContent = calibrationIntent === "start" ? "게임 시작" : "게임으로 돌아가기";
    action.disabled = false;
    return;
  }

  if (phase === "neutral") {
    title.textContent = "둘 다 중앙에 놓으세요";
    copy.textContent = "IMU를 평평하게 두고 조이스틱에서 손을 뗀 채 잠시 유지하세요.";
    stepLabel.textContent = "1 / 3";
    action.textContent = "중앙 위치 저장";
  } else if (phase === "imu_right") {
    title.textContent = "IMU를 오른쪽으로 기울이세요";
    copy.textContent = "게임 화면의 오른쪽으로 움직인다고 생각하고 IMU를 충분히 기울여 유지하세요.";
    stepLabel.textContent = "2 / 3";
    action.textContent = "오른쪽 방향 저장";
  } else if (phase === "joystick_right") {
    title.textContent = "조이스틱을 오른쪽으로 미세요";
    copy.textContent = "게임 화면 기준 오른쪽 끝까지 조이스틱을 밀고 그대로 유지하세요.";
    stepLabel.textContent = "3 / 3";
    action.textContent = "오른쪽 방향 저장";
  } else {
    title.textContent = "컨트롤러 방향을 맞춥니다";
    copy.textContent = "센서 응답을 확인하고 동기화를 준비하고 있습니다.";
    stepLabel.textContent = "준비";
    action.textContent = "동기화 시작";
  }

  const error = state.calibration.error;
  status.textContent = error || (state.calibration.sampleReady
    ? "센서 값이 안정되었습니다. 현재 위치를 저장하세요."
    : `센서 안정화 중 · ${Math.min(state.calibration.sampleCount, 20)} / 20`);
  action.disabled = phase === "idle" ? calibrationBeginRequested : !state.calibration.sampleReady;
}

function requestCalibrationBegin(): void {
  if (!hasDirectionModules(latestState) || calibrationBeginRequested) return;
  calibrationBeginRequested = true;
  input.calibrate("begin");
  renderCalibration(latestState);
}

function openCalibration(intent: "start" | "resume"): void {
  calibrationIntent = intent;
  calibrationBeginRequested = false;
  calibrationModal.classList.add("is-visible");
  renderCalibration(latestState);
  requestCalibrationBegin();
}

const game = new ElementGame(canvas, input, {
  onStage: (stage) => {
    element("#hud-stage").textContent = `STAGE ${String(stage.id).padStart(2, "0")}`;
    element("#hud-title").textContent = stage.title;
    document.documentElement.style.setProperty("--stage-accent", stage.theme.accent);
    showStageIntro(stage);
  },
  onMission: (index, text, completed) => {
    element("#mission-index").textContent = String(index).padStart(2, "0");
    element("#mission-text").textContent = text;
    element("#mission-check").classList.toggle("is-complete", completed);
  },
  onProgress: (value) => {
    element<HTMLElement>("#progress-fill").style.width = `${Math.round(value * 100)}%`;
  },
  onActiveElement: (active: ElementKind) => {
    document.body.dataset.activeElement = active;
  },
  onLed: (color, label) => {
    const cssColor = `rgb(${color.map((channel) => Math.round(channel * 2.55)).join(",")})`;
    element<HTMLElement>("#led-preview").style.setProperty("--led-color", cssColor);
    element("#led-value").textContent = label;
  },
  onSpeaker: (label) => {
    element("#speaker-value").textContent = label;
    window.setTimeout(() => {
      element("#speaker-value").textContent = "준비";
    }, 900);
  },
  onToast: showToast,
  onVictory: ({ restarts, elapsed, relics, totalRelics }) => {
    setGameplayUi(false);
    victoryScreen.classList.add("screen--visible");
    const minutes = Math.floor(elapsed / 60);
    const seconds = Math.floor(elapsed % 60);
    element("#victory-stats").textContent = `3개의 유적 · 기억 ${relics}/${totalRelics} · ${restarts}번의 재시작 · ${minutes}:${String(seconds).padStart(2, "0")}`;
  },
});

function beginGame(): void {
  startScreen.classList.remove("screen--visible");
  victoryScreen.classList.remove("screen--visible");
  guideModal.classList.remove("is-visible");
  calibrationModal.classList.remove("is-visible");
  input.finishCalibration();
  setGameplayUi(true);
  game.start();
}

function requestGameStart(): void {
  guideModal.classList.remove("is-visible");
  if (hasDirectionModules(latestState) && !latestState.calibration.calibrated) {
    openCalibration("start");
    return;
  }
  if (latestState?.source === "hardware" && !hasDirectionModules(latestState)) {
    openCalibration("start");
    return;
  }
  beginGame();
}

element<HTMLButtonElement>("#start-button").addEventListener("click", requestGameStart);
element<HTMLButtonElement>("#guide-start-button").addEventListener("click", requestGameStart);
element<HTMLButtonElement>("#open-guide-button").addEventListener("click", () => guideModal.classList.add("is-visible"));
element<HTMLButtonElement>("#guide-close").addEventListener("click", () => guideModal.classList.remove("is-visible"));
element<HTMLButtonElement>("#play-again-button").addEventListener("click", beginGame);

element<HTMLButtonElement>("#calibration-open").addEventListener("click", () => {
  if (game.isPlaying() && !game.isPaused()) game.pause();
  openCalibration("resume");
});

element<HTMLButtonElement>("#calibration-action").addEventListener("click", () => {
  if (!latestState) return;
  const phase = latestState.calibration.phase;
  if (phase === "complete") {
    calibrationModal.classList.remove("is-visible");
    input.finishCalibration();
    if (calibrationIntent === "start") beginGame();
    else game.resume();
    return;
  }
  if (phase === "idle") {
    calibrationBeginRequested = false;
    requestCalibrationBegin();
    return;
  }
  input.calibrate("capture");
});

element<HTMLButtonElement>("#calibration-cancel").addEventListener("click", () => {
  input.calibrate("cancel");
  calibrationModal.classList.remove("is-visible");
  calibrationBeginRequested = false;
  if (calibrationIntent === "resume") game.resume();
});

element<HTMLButtonElement>("#pause-button").addEventListener("click", () => {
  game.pause();
  pauseModal.classList.add("is-visible");
});
element<HTMLButtonElement>("#resume-button").addEventListener("click", () => {
  game.resume();
  pauseModal.classList.remove("is-visible");
});
element<HTMLButtonElement>("#restart-button").addEventListener("click", () => {
  game.restart();
  pauseModal.classList.remove("is-visible");
});

element<HTMLButtonElement>("#simulator-toggle").addEventListener("click", () => simulatorPanel.classList.add("is-visible"));
element<HTMLButtonElement>("#simulator-close").addEventListener("click", () => simulatorPanel.classList.remove("is-visible"));

const rollSlider = element<HTMLInputElement>("#sim-roll");
rollSlider.addEventListener("input", () => {
  const value = Number(rollSlider.value);
  element<HTMLOutputElement>("#sim-roll-output").value = `${value}°`;
  input.setSimulationRoll(value);
});

document.querySelectorAll<HTMLButtonElement>("[data-joy]").forEach((button) => {
  button.addEventListener("pointerdown", () => {
    const direction = button.dataset.joy as "up" | "down" | "left" | "right" | "origin";
    input.pushSimulationDirection(direction);
    element<HTMLOutputElement>("#sim-joystick-output").value = button.textContent === "●" ? "중앙" : button.textContent ?? "중앙";
  });
  button.addEventListener("pointerup", () => input.pushSimulationDirection("origin"));
  button.addEventListener("pointerleave", () => input.pushSimulationDirection("origin"));
});

function bindHold(selector: string, handler: (active: boolean) => void): void {
  const button = element<HTMLButtonElement>(selector);
  const start = (event: PointerEvent): void => {
    event.preventDefault();
    button.setPointerCapture(event.pointerId);
    button.classList.add("is-held");
    handler(true);
  };
  const end = (): void => {
    button.classList.remove("is-held");
    handler(false);
  };
  button.addEventListener("pointerdown", start);
  button.addEventListener("pointerup", end);
  button.addEventListener("pointercancel", end);
  button.addEventListener("lostpointercapture", end);
}

bindHold("#sim-heat", (active) => input.setSimulationHeat(active));
bindHold("#sim-dark", (active) => input.setSimulationDark(active));
element<HTMLButtonElement>("#sim-button").addEventListener("click", () => input.pressSimulationButton());
element<HTMLButtonElement>("#sim-switch").addEventListener("click", () => input.switchSimulationPlayer());

guideModal.addEventListener("click", (event) => {
  if (event.target === guideModal) guideModal.classList.remove("is-visible");
});

input.subscribe((state) => {
  latestState = state;
  updateModuleDock(state);
  updateStartState(state);
  renderCalibration(state);
  if (
    !autoCalibrationOffered
    && startScreen.classList.contains("screen--visible")
    && hasDirectionModules(state)
    && state.calibration.required
  ) {
    autoCalibrationOffered = true;
    openCalibration("start");
  }
  if (calibrationModal.classList.contains("is-visible") && hasDirectionModules(state)) {
    requestCalibrationBegin();
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.hidden && game.isPlaying() && !game.isPaused()) {
    game.pause();
    pauseModal.classList.add("is-visible");
  }
});
