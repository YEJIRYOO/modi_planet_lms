# EMBER & TIDE

MODI PLUS의 IMU, JOYSTICK, ENV, BUTTON, LED, SPEAKER를 실제 게임 규칙에 연결한 3스테이지 웹 퍼즐 플랫포머입니다.

## 한 번에 실행

```bash
./game_run main.py
```

이 명령 하나가 웹 게임과 MODI PLUS 컨트롤러를 함께 실행합니다. 브라우저에서 `http://localhost:5174`를 열고, 종료할 때는 실행한 터미널에서 `Ctrl+C`를 누르세요.

실물 IMU와 JOYSTICK이 연결되어 있으면 처음 탐험을 시작할 때 방향 동기화가 자동으로 열립니다.

1. IMU를 평평하게 놓고 조이스틱에서 손을 떼어 중앙값을 저장합니다.
2. IMU를 게임 화면 기준 오른쪽으로 기울여 장착 축과 방향을 저장합니다.
3. 조이스틱을 게임 화면 기준 오른쪽 끝까지 밀어 축과 방향을 저장합니다.

게임 중 방향이 달라졌다면 MODI 상태 패널의 `다시 맞추기`를 누르면 됩니다.

현재 장치를 자동으로 찾지 못하는 경우에는 직렬 포트를 함께 지정합니다.

```bash
./game_run main.py --serial-port /dev/cu.usbmodem928681B90F481
```

실물 MODI 없이 전체 연결을 확인하려면 모의 모드로 실행합니다.

```bash
./game_run main.py --mock
```

## MODI PLUS 연결

전체 MODI 제어 코드와 IMU/JOYSTICK 동기화 엔진은 루트의 `main.py` 한 파일에 들어 있습니다. 별도의 브리지나 보정 파일을 먼저 실행할 필요가 없습니다. 처음 실행할 때 `game_run`이 필요한 패키지를 자동으로 확인하며, 수동 설치가 필요하면 다음 명령을 사용합니다.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Python 3.11–3.13을 권장합니다. 이미 포트 `8765`에서 예전 브리지를 실행 중이라면 먼저 그 터미널에서 `Ctrl+C`로 종료한 다음 통합 실행기를 사용하세요.

## 조작

- IMU 좌우 기울기 / `A`, `D`: 이동
- BUTTON 누름 / `Space`: 점프
- BUTTON 더블클릭 / `Tab`: EMBER ↔ TIDE 전환
- JOYSTICK / 방향키: 퍼즐 방향 입력
- ENV 가열 / `H` 유지: 온도 기믹
- ENV 가리기 / `L` 유지: 조도 기믹

## 검증

```bash
npm test
npm run build
```

게임과 하드웨어 규칙은 [게임 설계](docs/GAME_DESIGN.md)를 참고하세요.
