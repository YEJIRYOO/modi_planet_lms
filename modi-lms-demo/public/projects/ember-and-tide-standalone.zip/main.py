#!/usr/bin/env python3
"""EMBER & TIDE standalone MODI PLUS controller.

This file owns the complete MODI USB -> WebSocket telemetry bridge and the
LED/SPEAKER output path. It intentionally has no dependency on another local
controller module so `./game_run main.py` is the only launch entry point.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import signal
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Any

try:
    from websockets.asyncio.server import ServerConnection, serve
except ImportError:  # websockets 13 compatibility
    from websockets.server import WebSocketServerProtocol as ServerConnection, serve


MODULE_NAMES = ("imu", "joystick", "env", "button", "led", "speaker")
MODULE_COLLECTIONS = {
    "imu": "imus",
    "joystick": "joysticks",
    "env": "envs",
    "button": "buttons",
    "led": "leds",
    "speaker": "speakers",
}
CALIBRATION_PHASES = ("neutral", "imu_right", "joystick_right")
CALIBRATION_MIN_SAMPLES = 20


def clamp_number(value: Any, minimum: float, maximum: float, fallback: float = 0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return fallback
    if not math.isfinite(number):
        return fallback
    return max(minimum, min(maximum, number))


def angle_delta(value: float, center: float) -> float:
    """Return the shortest signed angular distance in degrees."""
    return (value - center + 180) % 360 - 180


def circular_mean(values: list[float]) -> float:
    if not values:
        return 0
    sine = sum(math.sin(math.radians(value)) for value in values) / len(values)
    cosine = sum(math.cos(math.radians(value)) for value in values) / len(values)
    return math.degrees(math.atan2(sine, cosine))


def joystick_direction(x: float, y: float, threshold: float = 35) -> str:
    if max(abs(x), abs(y)) < threshold:
        return "origin"
    if abs(x) >= abs(y):
        return "right" if x > 0 else "left"
    return "up" if y > 0 else "down"


@dataclass
class DirectionCalibration:
    """Learns neutral offsets plus the physical right direction of both inputs."""

    active: bool = False
    calibrated: bool = False
    phase: str = "idle"
    error: str = ""
    imu_center_x: float = 0
    imu_center_y: float = 0
    joystick_center_x: float = 0
    joystick_center_y: float = 0
    imu_axis: str = "x"
    imu_sign: int = 1
    joystick_axis: str = "x"
    joystick_sign: int = 1
    samples: list[tuple[float, float, float, float]] = field(default_factory=list, repr=False)
    _backup: tuple[float, float, float, float, str, int, str, int] | None = field(
        default=None, repr=False
    )

    def begin(self) -> None:
        if self.calibrated:
            self._backup = (
                self.imu_center_x,
                self.imu_center_y,
                self.joystick_center_x,
                self.joystick_center_y,
                self.imu_axis,
                self.imu_sign,
                self.joystick_axis,
                self.joystick_sign,
            )
        else:
            self._backup = None
        self.active = True
        self.calibrated = False
        self.phase = "neutral"
        self.error = ""
        self.samples.clear()

    def cancel(self) -> None:
        if self._backup is not None:
            (
                self.imu_center_x,
                self.imu_center_y,
                self.joystick_center_x,
                self.joystick_center_y,
                self.imu_axis,
                self.imu_sign,
                self.joystick_axis,
                self.joystick_sign,
            ) = self._backup
            self.calibrated = True
            self.phase = "complete"
        else:
            self.calibrated = False
            self.phase = "idle"
        self.active = False
        self.error = ""
        self.samples.clear()
        self._backup = None

    def invalidate(self, message: str = "컨트롤러가 다시 연결되어 재동기화가 필요합니다.") -> None:
        self.active = False
        self.calibrated = False
        self.phase = "idle"
        self.error = message
        self.samples.clear()
        self._backup = None

    def observe(self, imu_x: float, imu_y: float, joystick_x: float, joystick_y: float) -> None:
        if not self.active or self.phase not in CALIBRATION_PHASES:
            return
        self.samples.append((imu_x, imu_y, joystick_x, joystick_y))
        if len(self.samples) > 75:
            del self.samples[:-75]

    def capture(self) -> bool:
        """Capture the current phase; return True only when calibration completes."""
        if not self.active or self.phase not in CALIBRATION_PHASES:
            self.error = "먼저 방향 동기화를 시작하세요."
            return False
        if len(self.samples) < CALIBRATION_MIN_SAMPLES:
            self.error = "잠시 그대로 유지해 주세요. 센서 값을 모으고 있습니다."
            return False

        recent = self.samples[-CALIBRATION_MIN_SAMPLES:]
        imu_x = circular_mean([sample[0] for sample in recent])
        imu_y = circular_mean([sample[1] for sample in recent])
        joystick_x = sum(sample[2] for sample in recent) / len(recent)
        joystick_y = sum(sample[3] for sample in recent) / len(recent)

        if self.phase == "neutral":
            imu_spread = max(
                max(abs(angle_delta(sample[0], imu_x)), abs(angle_delta(sample[1], imu_y)))
                for sample in recent
            )
            joystick_spread = max(
                math.hypot(sample[2] - joystick_x, sample[3] - joystick_y) for sample in recent
            )
            if imu_spread > 4 or joystick_spread > 15:
                self.error = "센서가 움직이고 있습니다. 둘 다 중앙에 놓고 다시 시도하세요."
                self.samples.clear()
                return False
            self.imu_center_x = imu_x
            self.imu_center_y = imu_y
            self.joystick_center_x = joystick_x
            self.joystick_center_y = joystick_y
            self.phase = "imu_right"

        elif self.phase == "imu_right":
            delta_x = angle_delta(imu_x, self.imu_center_x)
            delta_y = angle_delta(imu_y, self.imu_center_y)
            if max(abs(delta_x), abs(delta_y)) < 8:
                self.error = "IMU 변화가 작습니다. 화면 오른쪽으로 더 기울여 주세요."
                self.samples.clear()
                return False
            self.imu_axis = "x" if abs(delta_x) >= abs(delta_y) else "y"
            selected = delta_x if self.imu_axis == "x" else delta_y
            self.imu_sign = 1 if selected > 0 else -1
            self.phase = "joystick_right"

        else:
            delta_x = joystick_x - self.joystick_center_x
            delta_y = joystick_y - self.joystick_center_y
            if max(abs(delta_x), abs(delta_y)) < 35:
                self.error = "조이스틱 변화가 작습니다. 오른쪽 끝까지 밀어 주세요."
                self.samples.clear()
                return False
            self.joystick_axis = "x" if abs(delta_x) >= abs(delta_y) else "y"
            selected = delta_x if self.joystick_axis == "x" else delta_y
            self.joystick_sign = 1 if selected > 0 else -1
            self.active = False
            self.calibrated = True
            self.phase = "complete"
            self._backup = None
            self.error = ""
            self.samples.clear()
            return True

        self.error = ""
        self.samples.clear()
        return False

    def normalize_imu(self, raw_x: float, raw_y: float) -> tuple[float, float]:
        delta_x = angle_delta(raw_x, self.imu_center_x)
        delta_y = angle_delta(raw_y, self.imu_center_y)
        selected = delta_x if self.imu_axis == "x" else delta_y
        other = delta_y if self.imu_axis == "x" else delta_x
        return selected * self.imu_sign, other

    def normalize_joystick(self, raw_x: float, raw_y: float) -> tuple[float, float]:
        delta_x = raw_x - self.joystick_center_x
        delta_y = raw_y - self.joystick_center_y
        if self.joystick_axis == "x":
            return delta_x * self.joystick_sign, delta_y * self.joystick_sign
        return delta_y * self.joystick_sign, -delta_x * self.joystick_sign

    def status(self, available: bool) -> dict[str, Any]:
        return {
            "available": available,
            "required": available and not self.calibrated,
            "active": self.active,
            "calibrated": self.calibrated,
            "phase": self.phase,
            "sampleCount": len(self.samples),
            "sampleReady": len(self.samples) >= CALIBRATION_MIN_SAMPLES,
            "error": self.error,
            "imuAxis": self.imu_axis,
            "imuSign": self.imu_sign,
            "joystickAxis": self.joystick_axis,
            "joystickSign": self.joystick_sign,
        }


@dataclass
class ModuleSet:
    imu: Any = None
    joystick: Any = None
    env: Any = None
    button: Any = None
    led: Any = None
    speaker: Any = None

    def status(self) -> dict[str, bool]:
        return {name: getattr(self, name) is not None for name in MODULE_NAMES}


class ModiController:
    """Discovers live modules, samples inputs, and applies safe outputs."""

    def __init__(self, serial_port: str | None = None, verbose: bool = False) -> None:
        self.serial_port = serial_port
        self.verbose = verbose
        self.bundle: Any = None
        self.modules = ModuleSet()
        self.calibration = DirectionCalibration()
        self._calibration_lock = threading.RLock()
        self._tone_timer: threading.Timer | None = None

    def connect(self) -> None:
        try:
            import modi_plus
        except ImportError as error:
            raise RuntimeError(
                "pymodi-plus가 없습니다. 먼저 .venv/bin/python -m pip install -r requirements.txt 를 실행하세요."
            ) from error

        if self.serial_port:
            self._patch_explicit_port_open(self.serial_port)

        options: dict[str, Any] = {"connection_type": "serialport", "verbose": self.verbose}
        if self.serial_port:
            options["port"] = self.serial_port

        self.bundle = modi_plus.MODIPlus(**options)
        self._refresh_modules(announce=False)
        detected = [name.upper() for name, present in self.modules.status().items() if present]
        print(f"[MODI] 초기 게임 모듈: {', '.join(detected) if detected else '검색 중'}", flush=True)

    @staticmethod
    def _patch_explicit_port_open(default_port: str) -> None:
        """Work around PyMODI+ 0.4.2's missing explicit-port forwarding."""
        from modi_plus.util.modi_serialport import ModiSerialPort

        ModiSerialPort._ember_tide_default_port = default_port  # type: ignore[attr-defined]
        if getattr(ModiSerialPort.open, "_ember_tide_compatible", False):
            return
        original_open = ModiSerialPort.open

        def compatible_open(instance: Any, port: str | None = None) -> None:
            selected = port or getattr(instance, "_port", None) or getattr(
                ModiSerialPort, "_ember_tide_default_port", None
            )
            if not selected:
                raise TypeError("MODI+ serial port was not provided")
            original_open(instance, selected)

        compatible_open._ember_tide_compatible = True  # type: ignore[attr-defined]
        ModiSerialPort.open = compatible_open

    def _first(self, collection_name: str) -> Any:
        collection = getattr(self.bundle, collection_name, ())
        try:
            return collection[0] if len(collection) else None
        except (IndexError, TypeError):
            return None

    def _refresh_modules(self, announce: bool = True) -> None:
        """Adopt late modules and new instances created by a reconnect."""
        if self.bundle is None:
            return
        for module_name, collection_name in MODULE_COLLECTIONS.items():
            discovered = self._first(collection_name)
            current = getattr(self.modules, module_name)
            if discovered is None or discovered is current:
                continue
            setattr(self.modules, module_name, discovered)
            if current is not None and module_name in {"imu", "joystick"}:
                with self._calibration_lock:
                    self.calibration.invalidate()
            if announce:
                module_id = getattr(discovered, "id", None)
                label = f" (0x{module_id:X})" if isinstance(module_id, int) else ""
                print(f"[MODI] {module_name.upper()}{label} 등록/갱신", flush=True)

    @staticmethod
    def _read(module: Any, property_name: str, fallback: Any) -> Any:
        if module is None:
            return fallback
        try:
            return getattr(module, property_name)
        except Exception:
            return fallback

    def read_imu(self) -> tuple[float, float, float]:
        """Read the three IMU angles before direction normalization."""
        imu = self.modules.imu
        return (
            clamp_number(self._read(imu, "angle_x", 0), -180, 180),
            clamp_number(self._read(imu, "angle_y", 0), -180, 180),
            clamp_number(self._read(imu, "angle_z", 0), -180, 180),
        )

    def read_joystick(self) -> tuple[float, float]:
        """Read the joystick axes before mounting-direction normalization."""
        joystick = self.modules.joystick
        return (
            clamp_number(self._read(joystick, "x", 0), -100, 100),
            clamp_number(self._read(joystick, "y", 0), -100, 100),
        )

    def read_env(self) -> dict[str, float]:
        """Read the environment values used by heat and darkness puzzles."""
        env = self.modules.env
        return {
            "temperature": round(clamp_number(self._read(env, "temperature", 24), -10, 60), 1),
            "illuminance": round(clamp_number(self._read(env, "illuminance", 72), 0, 100)),
            "humidity": round(clamp_number(self._read(env, "humidity", 45), 0, 100)),
            "volume": round(clamp_number(self._read(env, "volume", 0), 0, 100)),
        }

    def read_button(self) -> dict[str, bool]:
        """Keep single-press jump and double-click character switching separate."""
        button = self.modules.button
        return {
            "pressed": bool(self._read(button, "pressed", False)),
            "clicked": bool(self._read(button, "clicked", False)),
            "doubleClicked": bool(self._read(button, "double_clicked", False)),
        }

    def telemetry(self) -> dict[str, Any]:
        self._refresh_modules()
        raw_imu_x, raw_imu_y, raw_imu_z = self.read_imu()
        raw_joystick_x, raw_joystick_y = self.read_joystick()
        calibration_available = self.modules.imu is not None and self.modules.joystick is not None

        with self._calibration_lock:
            self.calibration.observe(raw_imu_x, raw_imu_y, raw_joystick_x, raw_joystick_y)
            normalized_roll, normalized_pitch = self.calibration.normalize_imu(raw_imu_x, raw_imu_y)
            normalized_x, normalized_y = self.calibration.normalize_joystick(
                raw_joystick_x, raw_joystick_y
            )
            calibration_status = self.calibration.status(calibration_available)

        normalized_x = clamp_number(normalized_x, -100, 100)
        normalized_y = clamp_number(normalized_y, -100, 100)
        direction = joystick_direction(normalized_x, normalized_y)

        return {
            "type": "telemetry",
            "connected": True,
            "source": "hardware",
            "modules": self.modules.status(),
            "calibration": calibration_status,
            "imu": {
                "roll": round(clamp_number(normalized_roll, -180, 180), 2),
                "pitch": round(clamp_number(normalized_pitch, -180, 180), 2),
                "yaw": round(raw_imu_z, 2),
            },
            "joystick": {
                "x": round(normalized_x),
                "y": round(normalized_y),
                "direction": direction,
            },
            "env": self.read_env(),
            "button": self.read_button(),
            "timestamp": int(time.time() * 1000),
        }

    def set_led(self, color: Any) -> None:
        """Set LED RGB values after validating the browser command."""
        if self.modules.led is None or not isinstance(color, list) or len(color) != 3:
            return
        red, green, blue = (round(clamp_number(channel, 0, 100)) for channel in color)
        self.modules.led.set_rgb(red, green, blue)

    def play_tone(self, frequency: Any, volume: Any, duration: Any) -> None:
        """Play one speaker tone and stop it automatically."""
        if self.modules.speaker is None:
            return
        safe_frequency = round(clamp_number(frequency, 0, 20000))
        safe_volume = round(clamp_number(volume, 0, 100))
        safe_duration = round(clamp_number(duration, 20, 3000, 120))
        self.modules.speaker.set_tune(safe_frequency, safe_volume)
        if self._tone_timer:
            self._tone_timer.cancel()
        self._tone_timer = threading.Timer(safe_duration / 1000, self._stop_tone)
        self._tone_timer.daemon = True
        self._tone_timer.start()

    def play_music(self, name: Any, volume: Any) -> None:
        """Play a named MODI melody, falling back to a short success tone."""
        if self.modules.speaker is None:
            return
        safe_name = str(name or "Success")
        safe_volume = round(clamp_number(volume, 0, 100, 70))
        try:
            self.modules.speaker.play_music(safe_name, safe_volume)
        except (ValueError, AttributeError):
            self.modules.speaker.set_tune(784, safe_volume)

    def apply(self, command: dict[str, Any]) -> None:
        self._refresh_modules()
        action = command.get("action")

        if action == "calibrate":
            operation = command.get("operation")
            completed = False
            with self._calibration_lock:
                if operation in {"begin", "reset"}:
                    if self.modules.imu is None or self.modules.joystick is None:
                        self.calibration.error = "IMU와 JOYSTICK을 모두 연결하세요."
                    else:
                        self.calibration.begin()
                        print("[SYNC] 중앙값 수집 시작", flush=True)
                elif operation == "capture":
                    previous_phase = self.calibration.phase
                    completed = self.calibration.capture()
                    if not self.calibration.error:
                        print(f"[SYNC] {previous_phase} 캡처 완료", flush=True)
                elif operation == "cancel":
                    self.calibration.cancel()
                    print("[SYNC] 방향 동기화 취소", flush=True)
            if completed:
                self._calibration_success_feedback()
                print(
                    "[SYNC] 완료: "
                    f"IMU={self.calibration.imu_axis}/{self.calibration.imu_sign:+d}, "
                    f"JOYSTICK={self.calibration.joystick_axis}/{self.calibration.joystick_sign:+d}",
                    flush=True,
                )
            return

        if action == "led" and self.modules.led is not None:
            self.set_led(command.get("color", [0, 0, 0]))
            return

        if action == "tone" and self.modules.speaker is not None:
            self.play_tone(
                command.get("frequency"),
                command.get("volume"),
                command.get("duration"),
            )
            return

        if action == "music" and self.modules.speaker is not None:
            self.play_music(command.get("name", "Success"), command.get("volume", 70))
            return

        if action == "stop":
            self._stop_tone()
            if self.modules.speaker is not None:
                try:
                    self.modules.speaker.stop_music()
                except Exception:
                    pass

    def _calibration_success_feedback(self) -> None:
        if self.modules.led is not None:
            try:
                self.modules.led.set_rgb(20, 100, 72)
            except Exception:
                pass
        if self.modules.speaker is not None:
            try:
                self.modules.speaker.set_tune(880, 45)
                if self._tone_timer:
                    self._tone_timer.cancel()
                self._tone_timer = threading.Timer(0.16, self._stop_tone)
                self._tone_timer.daemon = True
                self._tone_timer.start()
            except Exception:
                pass

    def _stop_tone(self) -> None:
        if self.modules.speaker is None:
            return
        try:
            self.modules.speaker.reset()
        except Exception:
            pass

    def close(self) -> None:
        if self._tone_timer:
            self._tone_timer.cancel()
        if self.modules.led is not None:
            try:
                self.modules.led.turn_off()
            except Exception:
                pass
        self._stop_tone()
        if self.bundle is not None:
            try:
                self.bundle.close()
            except Exception:
                pass


class MockController(ModiController):
    def connect(self) -> None:
        class MockImu:
            angle_x = 0
            angle_y = 0
            angle_z = 0

        class MockJoystick:
            x = 0
            y = 0
            direction = "origin"

        class MockEnv:
            temperature = 24
            illuminance = 72
            humidity = 45
            volume = 0

        class MockButton:
            pressed = False
            clicked = False
            double_clicked = False

        class MockOutput:
            def set_rgb(self, *_: Any) -> None:
                pass

            def turn_off(self) -> None:
                pass

            def set_tune(self, *_: Any) -> None:
                pass

            def reset(self) -> None:
                pass

            def play_music(self, *_: Any) -> None:
                pass

            def stop_music(self) -> None:
                pass

        self.modules = ModuleSet(
            imu=MockImu(),
            joystick=MockJoystick(),
            env=MockEnv(),
            button=MockButton(),
            led=MockOutput(),
            speaker=MockOutput(),
        )
        print("[MODI] MOCK 모드: 6개 모듈 가상 연결", flush=True)

    def telemetry(self) -> dict[str, Any]:
        self.modules.imu.angle_x = 18 if self.calibration.phase == "imu_right" else 0
        self.modules.joystick.x = 75 if self.calibration.phase == "joystick_right" else 0
        return super().telemetry()

    def apply(self, command: dict[str, Any]) -> None:
        action = command.get("action", "unknown")
        if action == "calibrate":
            super().apply(command)
        elif action in {"led", "tone", "music", "stop"}:
            print(f"[MOCK OUTPUT] {action}", flush=True)

    def close(self) -> None:
        pass


class WebSocketBridge:
    def __init__(self, controller: ModiController, host: str, port: int, rate: float) -> None:
        self.controller = controller
        self.host = host
        self.port = port
        self.rate = max(10, min(60, rate))
        self.clients: set[ServerConnection] = set()
        self.stop_event = asyncio.Event()

    async def handle_client(self, websocket: ServerConnection) -> None:
        self.clients.add(websocket)
        print(f"[WEB] 게임 연결 ({len(self.clients)})", flush=True)
        try:
            await websocket.send(json.dumps(await asyncio.to_thread(self.controller.telemetry)))
            async for raw_message in websocket:
                try:
                    message = json.loads(raw_message)
                except (json.JSONDecodeError, TypeError):
                    continue
                if isinstance(message, dict) and message.get("type") == "command":
                    await asyncio.to_thread(self.controller.apply, message)
        except Exception as error:
            if "closed" not in type(error).__name__.lower():
                print(f"[WEB] 연결 오류: {error}", file=sys.stderr, flush=True)
        finally:
            self.clients.discard(websocket)
            print(f"[WEB] 게임 연결 종료 ({len(self.clients)})", flush=True)

    async def broadcast(self) -> None:
        interval = 1 / self.rate
        while not self.stop_event.is_set():
            started = time.monotonic()
            if self.clients:
                data = await asyncio.to_thread(self.controller.telemetry)
                payload = json.dumps(data, separators=(",", ":"))
                disconnected: list[ServerConnection] = []
                for client in tuple(self.clients):
                    try:
                        await client.send(payload)
                    except Exception:
                        disconnected.append(client)
                for client in disconnected:
                    self.clients.discard(client)
            elapsed = time.monotonic() - started
            try:
                await asyncio.wait_for(self.stop_event.wait(), timeout=max(0.002, interval - elapsed))
            except TimeoutError:
                pass

    async def run(self) -> None:
        loop = asyncio.get_running_loop()
        for signal_name in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(signal_name, self.stop_event.set)
            except (NotImplementedError, RuntimeError):
                pass

        print(f"[WEB] ws://{self.host}:{self.port} MODI 브리지 준비", flush=True)
        async with serve(self.handle_client, self.host, self.port, origins=None):
            task = asyncio.create_task(self.broadcast())
            await self.stop_event.wait()
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="EMBER & TIDE 통합 MODI PLUS 컨트롤러")
    parser.add_argument("--host", default="127.0.0.1", help="WebSocket 바인드 주소")
    parser.add_argument("--port", type=int, default=8765, help="WebSocket 포트")
    parser.add_argument("--serial-port", help="MODI PLUS 직렬 포트 (기본: 자동 검색)")
    parser.add_argument("--rate", type=float, default=50, help="텔레메트리 Hz (10-60)")
    parser.add_argument("--verbose", action="store_true", help="PyMODI+ 직렬 디버그 로그")
    parser.add_argument("--mock", action="store_true", help="실물 MODI 없이 프로토콜 시험")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    controller: ModiController = MockController() if args.mock else ModiController(args.serial_port, args.verbose)
    try:
        controller.connect()
        bridge = WebSocketBridge(controller, args.host, args.port, args.rate)
        asyncio.run(bridge.run())
    except KeyboardInterrupt:
        pass
    except Exception as error:
        print(f"[ERROR] {error}", file=sys.stderr, flush=True)
        return 1
    finally:
        controller.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
