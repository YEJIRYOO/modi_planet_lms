# Function Shape

목표 함수의 개형을 Dial, Joystick과 Button으로 맞추는 독립형 수학 게임입니다.

## MODI+ 모듈

- 필수: Network, Dial, Joystick, Button
- 선택: LED — 제출 결과 표시

## 조작법

- Dial: 선택된 계수의 값 조절
- Joystick 좌/우: 계수 선택, 길게 누르면 0.42초 간격 반복
- Joystick 위/아래: 0.1 단위 미세 조정, 길게 누르면 0.1초 간격 반복
- Button: 현재 그래프 제출

일차함수 `y=ax+b`, 절댓값함수 `y=a|x-h|+k`, 이차함수 `y=a(x-h)²+k`가 반복해서 출제됩니다. 전체 구간의 평균 그래프 오차를 이용해 정확도를 계산하며 90점 이상이면 통과합니다.

## 실행

```sh
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py --mode real --port 8501
```

브라우저: <http://127.0.0.1:8501>

Mock 모드:

```sh
python app.py --mode mock --port 8501
```

## 수업 연계

- 초등 고학년: 좌표평면에서 위치와 변화 관찰
- 중등: 일차함수의 기울기와 y절편, 그래프 이동
- 고등: 이차함수·절댓값함수의 계수와 개형, 오차함수

탐구 질문: `a`, `h`, `k` 중 어떤 값이 그래프의 방향·폭·위치를 바꿀까요?

## 연결 복구

Network 연결 후 Dial, Joystick 또는 Button이 늦게 나타나면 bundle을 닫지 않고 기다립니다. 실제 USB 통신 오류가 발생하면 1→2→4→8→15초 간격으로 자동 재연결하며 점수와 라운드는 유지됩니다.
