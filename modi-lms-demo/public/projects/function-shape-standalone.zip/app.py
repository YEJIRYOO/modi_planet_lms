#!/usr/bin/env python3
import argparse
import json
import math
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).parent
class ModuleUnavailableError(RuntimeError): pass

FAMILIES = {
    'linear': {'names': ['a', 'b'], 'ranges': {'a': (-3, 3), 'b': (-4, 4)}},
    'absolute': {'names': ['a', 'h', 'k'], 'ranges': {'a': (-3, 3), 'h': (-4, 4), 'k': (-4, 4)}},
    'quadratic': {'names': ['a', 'h', 'k'], 'ranges': {'a': (-2, 2), 'h': (-4, 4), 'k': (-4, 4)}},
}

class FunctionGame:
    def __init__(self, mode, factory=None):
        self.requested = mode
        self.factory = factory
        self.bundle = None
        self.error = None
        self.next_retry = 0
        self.retry_delay = 1
        self.lock = threading.RLock()
        self.random = random.Random(2026)
        self.last_button = False
        self.last_direction = 'origin'
        self.direction_since = 0
        self.last_repeat = 0
        self.round = 0
        self.total_score = 0
        self.next_round_at = 0
        self.new_round()

    @property
    def mode(self): return 'real' if self.bundle else 'mock'

    def connect(self):
        with self.lock:
            if self.requested == 'mock' or self.bundle or time.monotonic() < self.next_retry:
                return
            bundle = None
            try:
                if self.factory:
                    bundle = self.factory()
                else:
                    from modi_plus import MODIPlus
                    bundle = MODIPlus()
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline and not (bundle.dials and bundle.buttons and bundle.joysticks):
                    time.sleep(.1)
                self.bundle = bundle
                self.error = None if bundle.dials and bundle.buttons and bundle.joysticks else 'Waiting for Dial, Button and Joystick modules'
                self.retry_delay = 1
            except Exception as exc:
                self.error = str(exc)
                self.next_retry = time.monotonic() + self.retry_delay
                self.retry_delay = min(15, self.retry_delay * 2)
                if bundle:
                    try: bundle.close()
                    except Exception: pass

    def invalidate(self, exc):
        bundle, self.bundle = self.bundle, None
        self.error = f'connection lost: {exc}'
        self.next_retry = time.monotonic() + self.retry_delay
        self.retry_delay = min(15, self.retry_delay * 2)
        if bundle:
            try: bundle.close()
            except Exception: pass

    def new_round(self):
        self.round += 1
        self.family = ('linear', 'absolute', 'quadratic')[(self.round - 1) % 3]
        spec = FAMILIES[self.family]
        self.target = {}
        for name in spec['names']:
            low, high = spec['ranges'][name]
            value = self.random.choice([v / 2 for v in range(math.ceil(low * 2), math.floor(high * 2) + 1) if v != 0 or name != 'a'])
            self.target[name] = value
        self.params = {name: (1 if name == 'a' else 0) for name in spec['names']}
        self.nudges = {name: 0 for name in spec['names']}
        self.selected = 0
        self.accuracy = 0
        self.feedback = 'shape_the_graph'
        self.solved = False

    @staticmethod
    def value(family, params, x):
        if family == 'linear': return params['a'] * x + params['b']
        if family == 'absolute': return params['a'] * abs(x - params['h']) + params['k']
        return params['a'] * (x - params['h']) ** 2 + params['k']

    def grade(self):
        errors = []
        for index in range(81):
            x = -5 + index / 8
            target = self.value(self.family, self.target, x)
            current = self.value(self.family, self.params, x)
            errors.append(min(16, abs(target - current)))
        mean_error = sum(errors) / len(errors)
        return max(0, min(100, round(100 * (1 - mean_error / 8))))

    def state(self, body):
        with self.lock:
            try:
                return self._state(body)
            except (ModuleUnavailableError, ValueError, TypeError):
                raise
            except Exception as exc:
                if self.bundle: self.invalidate(exc)
                raise

    def _state(self, body):
        self.connect()
        if self.requested == 'real' and not self.bundle:
            raise RuntimeError(self.error or 'MODI+ is not connected')
        if self.bundle and (not self.bundle.dials or not self.bundle.buttons or not self.bundle.joysticks):
            raise ModuleUnavailableError('Connected to Network; waiting for Dial, Button and Joystick modules')
        now = time.monotonic()
        if self.solved and now >= self.next_round_at:
            self.new_round()

        physical_button = bool(self.bundle.buttons[0].pressed) if self.bundle else False
        button = physical_button or bool(body.get('button', False))
        submitted = button and not self.last_button
        self.last_button = button
        direction = self.bundle.joysticks[0].direction or 'origin' if self.bundle else str(body.get('joystick', 'origin'))
        action = 'origin'
        if direction == 'origin':
            self.direction_since = 0
        elif direction != self.last_direction:
            action = direction
            self.direction_since = now
            self.last_repeat = now
        else:
            repeat_interval = .10 if direction in ('up', 'down') else .42
            if now - self.direction_since >= .35 and now - self.last_repeat >= repeat_interval:
                action = direction
                self.last_repeat = now
        self.last_direction = direction
        names = FAMILIES[self.family]['names']
        if action == 'left': self.selected = (self.selected - 1) % len(names)
        elif action == 'right': self.selected = (self.selected + 1) % len(names)
        selected_name = names[self.selected]
        low, high = FAMILIES[self.family]['ranges'][selected_name]
        if action in ('up', 'down'):
            self.nudges[selected_name] = round(self.nudges[selected_name] + (.1 if action == 'up' else -.1), 1)
        dial = float(self.bundle.dials[0].turn) if self.bundle else float(body.get('dial', 50))
        if not math.isfinite(dial): raise ValueError('Dial returned invalid data')
        dial = max(0, min(100, dial))
        self.params[selected_name] = round(max(low, min(high, low + dial / 100 * (high - low) + self.nudges[selected_name])), 1)

        if submitted and not self.solved:
            self.accuracy = self.grade()
            if self.accuracy >= 90:
                self.feedback = 'matched'
                self.solved = True
                self.total_score += self.accuracy
                self.next_round_at = now + 1.8
            elif self.accuracy >= 70: self.feedback = 'close'
            else: self.feedback = 'try_again'
            if self.bundle and self.bundle.leds:
                self.bundle.leds[0].set_rgb(*((80, 255, 100) if self.accuracy >= 90 else (255, 90, 30)))
        elif self.bundle and self.bundle.leds:
            self.bundle.leds[0].set_rgb(35, 110, 255)

        return {
            'mode': self.mode, 'family': self.family, 'round': self.round,
            'params': self.params, 'target': self.target, 'selected': selected_name,
            'dial': round(dial, 1), 'submitted': submitted,
            'accuracy': self.accuracy, 'feedback': self.feedback,
            'solved': self.solved, 'total_score': self.total_score,
        }

    def close(self):
        if self.bundle:
            for led in self.bundle.leds: led.turn_off()
            self.bundle.close()
            self.bundle = None

class Handler(BaseHTTPRequestHandler):
    game = None
    def send(self, status, value, kind='application/json'):
        try:
            data = json.dumps(value).encode() if kind == 'application/json' else value
            self.send_response(status); self.send_header('Content-Type', kind)
            self.send_header('Content-Length', str(len(data))); self.send_header('Cache-Control', 'no-store')
            self.end_headers(); self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError): pass
    def do_GET(self):
        if self.path == '/': self.send(200, (ROOT / 'index.html').read_bytes(), 'text/html; charset=utf-8')
        elif self.path == '/styles.css': self.send(200, (ROOT / 'styles.css').read_bytes(), 'text/css; charset=utf-8')
        elif self.path == '/app.js': self.send(200, (ROOT / 'app.js').read_bytes(), 'text/javascript; charset=utf-8')
        elif self.path == '/api/health':
            self.game.connect(); self.send(200, {'mode': self.game.mode, 'connected': bool(self.game.bundle), 'error': self.game.error})
        else: self.send(404, {'error': 'not found'})
    def do_POST(self):
        try:
            if self.path != '/api/state': self.send(404, {'error': 'not found'}); return
            size = int(self.headers.get('Content-Length', '0'))
            self.send(200, self.game.state(json.loads(self.rfile.read(size) or b'{}')))
        except Exception as exc: self.send(503, {'error': str(exc)})
    def log_message(self, *_): pass

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('auto', 'real', 'mock'), default='auto')
    parser.add_argument('--port', type=int, default=8501)
    args = parser.parse_args(); Handler.game = FunctionGame(args.mode)
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    print(f'Function Shape · http://127.0.0.1:{args.port}')
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: Handler.game.close(); server.server_close()

if __name__ == '__main__': main()
