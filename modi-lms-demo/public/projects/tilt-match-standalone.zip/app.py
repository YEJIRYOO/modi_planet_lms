#!/usr/bin/env python3
import argparse,json,math,random,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent
COLORS={'blue':(20,105,255),'orange':(255,95,25)}
class Game:
 def __init__(self,mode): self.requested=mode;self.bundle=None;self.error=None;self.next_retry=0;self.retry_delay=1;self.lock=threading.RLock();self.rng=random.Random();self.score=0;self.round=0;self.latched=False;self.feedback='center';self.new_round()
 @property
 def mode(self):return 'real' if self.bundle else 'mock'
 def connect(self):
  with self.lock:
   if self.requested=='mock' or self.bundle or time.monotonic()<self.next_retry:return
   b=None
   try:
    from modi_plus import MODIPlus
    b=MODIPlus()
    deadline=time.monotonic()+4
    while time.monotonic()<deadline and not (b.imus and b.leds):time.sleep(.1)
    if not b.imus or not b.leds:raise RuntimeError('Tilt Match requires IMU and LED modules')
    self.bundle=b;self.error=None;self.retry_delay=1
   except Exception as e:
    if b:
     try:b.close()
     except Exception:pass
    self.error=str(e)
    self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
 def invalidate(self,e):
  b,self.bundle=self.bundle,None;self.error=f'connection lost: {e}';self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
  if b:
   try:b.close()
   except Exception:pass
 def new_round(self):
  self.round+=1;self.left,self.right=(('blue','orange') if self.rng.random()<.5 else ('orange','blue'));self.target=self.rng.choice(('blue','orange'));self.target_side='left' if self.left==self.target else 'right'
 def status(self):self.connect();return {'status':'ok','mode':self.mode,'connected':bool(self.bundle),'error':self.error}
 def read(self,body):
  try:return self._read(body)
  except Exception as e:
   if self.bundle:self.invalidate(e)
   raise
 def _read(self,body):
  with self.lock:
   self.connect()
   if self.bundle:
    pitch=float(self.bundle.imus[0].angle_y);roll=float(self.bundle.imus[0].angle_x)
   else:
    pitch=float(body.get('pitch',0));roll=float(body.get('roll',0))
   neutral=float(body.get('neutral',0));axis=body.get('axis','roll');sign=float(body.get('sign',1));calibrating=bool(body.get('calibrating',False))
   if axis not in ('pitch','roll') or not all(math.isfinite(v) for v in (pitch,roll,neutral,sign)) or not sign:raise ValueError('invalid calibration or IMU angle')
   raw=pitch if axis=='pitch' else roll;delta=(raw-neutral)*(1 if sign>0 else -1);direction='center' if abs(delta)<10 else 'right' if delta>0 else 'left'
   if self.bundle:self.bundle.leds[0].set_rgb(*COLORS[self.target])
   if calibrating:
    self.latched=False;self.feedback='center';direction='center'
   elif direction=='center':
    if self.latched:self.latched=False;self.new_round()
    self.feedback='center'
   elif not self.latched:
    self.latched=True;correct=direction==self.target_side;self.score=max(0,self.score+(1 if correct else -1));self.feedback='correct' if correct else 'wrong'
   return {'mode':self.mode,'controls':{'pitch':round(pitch,1),'roll':round(roll,1)},'pitch':round(pitch,1),'roll':round(roll,1),'direction':direction,'left':self.left,'right':self.right,'target_color':self.target,'target_side':self.target_side,'score':self.score,'round':self.round,'feedback':self.feedback}
 def close(self):
  if self.bundle:
   for led in self.bundle.leds:led.turn_off()
   self.bundle.close();self.bundle=None
class Handler(BaseHTTPRequestHandler):
 game=None;assets={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css'}
 def json(self,s,v):
  d=json.dumps(v).encode();self.send_response(s);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(d)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(d)
 def do_GET(self):
  if self.path=='/api/health':self.json(200,self.game.status());return
  if self.path in self.assets:
   p=ROOT/self.assets[self.path];d=p.read_bytes();t='text/html' if p.suffix=='.html' else 'text/javascript' if p.suffix=='.js' else 'text/css';self.send_response(200);self.send_header('Content-Type',t);self.send_header('Content-Length',str(len(d)));self.end_headers();self.wfile.write(d);return
  self.json(404,{'error':'not found'})
 def do_POST(self):
  try:
   if self.path=='/api/stop':self.game.close();self.json(200,{'stopped':True});return
   if self.path!='/api/state':self.json(404,{'error':'not found'});return
   n=int(self.headers.get('Content-Length','0'));self.json(200,self.game.read(json.loads(self.rfile.read(n) or b'{}')))
  except Exception as e:self.json(503,{'error':str(e)})
 def log_message(self,*_):pass
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('auto','real','mock'),default='auto');p.add_argument('--port',type=int,default=8102);a=p.parse_args();Handler.game=Game(a.mode);s=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print(f'Tilt Match running at http://127.0.0.1:{a.port} ({a.mode})')
 try:s.serve_forever()
 except KeyboardInterrupt:pass
 finally:Handler.game.close();s.server_close()
if __name__=='__main__':main()
