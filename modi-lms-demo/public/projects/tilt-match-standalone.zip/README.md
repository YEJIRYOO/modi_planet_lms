# Tilt Match

```sh
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python app.py --mode auto --port 8102
```

Open <http://127.0.0.1:8102>. Requires an IMU and LED in real mode. Match the LED color to the same-colored light on screen and tilt toward it.
