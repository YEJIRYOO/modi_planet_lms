#!/usr/bin/env python3
import argparse,json,math,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
ROOT=Path(__file__).parent
class Studio:
 def __init__(self,mode,factory=None):self.requested=mode;self.factory=factory;self.bundle=None;self.error=None;self.next_retry=0;self.retry_delay=1;self.lock=threading.RLock();self.playing=False;self.last_button=False;self.volume=65;self.last_joystick_adjust=0;self.note_timer=None;self.note_generation=0;self.last_note=0;self.note_count=0
 @property
 def mode(self):return 'real' if self.bundle else 'mock'
 def connect(self):
  with self.lock:
   if self.requested=='mock' or self.bundle or time.monotonic()<self.next_retry:return
   b=None
   try:
    if self.factory:b=self.factory()
    else:
     from modi_plus import MODIPlus
     b=MODIPlus()
    deadline=time.monotonic()+5
    while time.monotonic()<deadline and not ((b.dials or b.joysticks) and b.buttons and b.speakers):time.sleep(.1)
    if not (b.dials or b.joysticks) or not b.buttons or not b.speakers:raise RuntimeError(f'Music Studio requires Dial (or Joystick), Button, and Speaker modules (found dial={len(b.dials)}, joystick={len(b.joysticks)}, button={len(b.buttons)}, speaker={len(b.speakers)})')
    self.bundle=b
    self.error=None
    self.retry_delay=1
   except Exception as e:
    if b:
     try:b.close()
     except Exception:pass
    self.error=str(e)
    self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
 def status(self):self.connect();return {'status':'ok','mode':self.mode,'connected':bool(self.bundle),'error':self.error,'retrying':self.requested!='mock' and not self.bundle}
 def drop_connection(self,error):
  b,self.bundle=self.bundle,None;self.error=str(error);self.next_retry=time.monotonic()+self.retry_delay;self.retry_delay=min(15,self.retry_delay*2)
  if b:
   try:b.close()
   except Exception:pass
 def state(self,body):
  with self.lock:
   self.connect()
   if self.requested=='real' and not self.bundle:raise RuntimeError(self.error or 'MODI+ is not connected')
   if self.bundle:
    try:
     if self.bundle.dials:self.volume=max(0,min(100,int(self.bundle.dials[0].turn)))
     else:
      direction=self.bundle.joysticks[0].direction;now=time.monotonic()
      if direction in ('up','down') and now-self.last_joystick_adjust>=.15:
       self.volume=max(0,min(100,self.volume+(5 if direction=='up' else -5)));self.last_joystick_adjust=now
     pressed=bool(self.bundle.buttons[0].pressed)
     if pressed and not self.last_button:self.playing=not self.playing
     self.last_button=pressed
    except Exception as e:
     self.drop_connection(e)
     if self.requested=='real':raise RuntimeError(f'MODI+ connection lost: {e}')
   else:self.volume=max(0,min(100,int(body.get('volume',self.volume))))
   control='dial' if self.bundle and self.bundle.dials else 'joystick' if self.bundle and self.bundle.joysticks else 'screen'
   return {'mode':self.mode,'playing':self.playing,'volume':self.volume,'volume_control':control,'last_note':self.last_note,'note_count':self.note_count}
 def toggle(self):
  with self.lock:self.playing=not self.playing;return {'playing':self.playing}
 def note(self,value,duration=.28,volume_override=None):
  with self.lock:
   frequency=float(value)
   if not math.isfinite(frequency) or not 80<=frequency<=2000:raise ValueError('frequency must be 80..2000 Hz')
   duration=float(duration)
   if not math.isfinite(duration) or not .08<=duration<=2:raise ValueError('duration must be 0.08..2 seconds')
   output_volume=self.volume if volume_override is None else int(volume_override)
   if not 0<=output_volume<=100:raise ValueError('volume must be 0..100')
   self.note_generation+=1;generation=self.note_generation;self.last_note=round(frequency);self.note_count+=1
   if self.bundle:
    try:self.bundle.speakers[0].set_tune(round(frequency),output_volume)
    except Exception as e:
     self.drop_connection(e)
     raise RuntimeError(f'MODI+ connection lost: {e}')
    if self.note_timer:self.note_timer.cancel()
    self.note_timer=threading.Timer(duration,self.silence,args=(generation,));self.note_timer.daemon=True;self.note_timer.start()
   return {'frequency':round(frequency),'volume':output_volume,'duration':duration,'note_count':self.note_count}
 def silence(self,generation=None):
  with self.lock:
   if generation is not None and generation!=self.note_generation:return
   if self.bundle:
    try:self.bundle.speakers[0].set_tune(0,0)
    except Exception as e:self.drop_connection(e)
 def close(self):
  with self.lock:
   if self.note_timer:self.note_timer.cancel()
   if self.bundle:
    for speaker in self.bundle.speakers:speaker.set_tune(0,0)
    self.bundle.close();self.bundle=None
class Handler(BaseHTTPRequestHandler):
 studio=None;assets={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css'}
 def json(self,s,v):
  try:
   d=json.dumps(v).encode();self.send_response(s);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(d)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(d)
  except (BrokenPipeError,ConnectionResetError):pass
 def body(self):n=int(self.headers.get('Content-Length','0'));return json.loads(self.rfile.read(n) or b'{}')
 def do_GET(self):
  if self.path=='/api/health':self.json(200,self.studio.status());return
  if self.path in self.assets:
   p=ROOT/self.assets[self.path];d=p.read_bytes();t='text/html' if p.suffix=='.html' else 'text/javascript' if p.suffix=='.js' else 'text/css';self.send_response(200);self.send_header('Content-Type',t);self.send_header('Content-Length',str(len(d)));self.end_headers();self.wfile.write(d);return
  self.json(404,{'error':'not found'})
 def do_POST(self):
  try:
   if self.path=='/api/state':self.json(200,self.studio.state(self.body()))
   elif self.path=='/api/toggle':self.json(200,self.studio.toggle())
   elif self.path=='/api/note':
    body=self.body();self.json(200,self.studio.note(body.get('frequency'),body.get('duration',.28),body.get('volume')))
   elif self.path=='/api/stop':self.studio.playing=False;self.studio.silence();self.json(200,{'stopped':True})
   else:self.json(404,{'error':'not found'})
  except Exception as e:self.json(503,{'error':str(e)})
 def log_message(self,*_):pass
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=('auto','real','mock'),default='auto');p.add_argument('--port',type=int,default=8103);a=p.parse_args();Handler.studio=Studio(a.mode);s=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print(f'Music Studio running at http://127.0.0.1:{a.port} ({a.mode})')
 try:s.serve_forever()
 except KeyboardInterrupt:pass
 finally:Handler.studio.close();s.server_close()
if __name__=='__main__':main()
