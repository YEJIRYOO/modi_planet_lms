# Loop Studio

```sh
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python app.py --mode auto --port 8103
```

Open <http://127.0.0.1:8103>. Real mode requires a Dial (or Joystick), Button, and Speaker. Dial sets absolute volume; when a Dial is unavailable, Joystick up/down adjusts it. Button toggles playback.

The sequencer uses F5, A5, C6, and E6 (698–1318 Hz), within the MODI+ Speaker's supported note range.
